'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import ProtectedModuleRoute from '../../../components/ProtectedModuleRoute'
import { supabase } from '../../../lib/supabase/client'

type CobranzaItem = {
  empresa_id: string
  movimiento_id: string
  cliente_id: string | null
  cuenta_bancaria_id: string | null
  fecha_emision: string | null
  fecha_vencimiento: string | null
  cliente: string | null
  numero_factura: string | null
  descripcion: string | null
  monto_total: number
  saldo_pendiente: number
  estado: 'pendiente' | 'parcial' | 'vencido' | 'pagado'
  monto_total_clp: string | null
  saldo_pendiente_clp: string | null
}

type CuentaBancaria = {
  id: string
  empresa_id: string
  banco: string
  nombre_cuenta: string
  tipo_cuenta: string | null
  moneda: string | null
  saldo_inicial: number | null
  activa: boolean
}

type PaymentFormState = {
  fecha_pago: string
  cuenta_bancaria_id: string
}

type RecordatorioResumen = {
  total: number
  ultimo: string | null
  ultimoEstado: string | null
}

const STORAGE_KEY = 'empresa_activa_id'

function todayLocalDate() {
  const now = new Date()
  const year = now.getFullYear()
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const day = String(now.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function formatDate(value: string | null | undefined) {
  if (!value) return '-'

  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value

  return new Intl.DateTimeFormat('es-CL', {
    day: '2-digit',
    month: '2-digit',
    year: '2-digit',
  }).format(date)
}

function formatDateTime(value: string | null | undefined) {
  if (!value) return '-'

  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '-'

  return new Intl.DateTimeFormat('es-CL', {
    day: '2-digit',
    month: '2-digit',
    year: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

function formatCLP(value: number | null | undefined) {
  if (value == null) return '$0'

  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    maximumFractionDigits: 0,
  }).format(value)
}

function estadoBadgeClass(estado: string | null | undefined) {
  switch ((estado || '').toLowerCase()) {
    case 'vencido':
      return 'border-red-200 bg-red-50 text-red-700'
    case 'parcial':
      return 'border-amber-200 bg-amber-50 text-amber-700'
    case 'pendiente':
      return 'border-blue-200 bg-blue-50 text-blue-700'
    case 'pagado':
      return 'border-emerald-200 bg-emerald-50 text-emerald-700'
    default:
      return 'border-slate-200 bg-slate-50 text-slate-700'
  }
}

function CobranzaPageContent() {
  const [empresaActivaId, setEmpresaActivaId] = useState('')
  const [items, setItems] = useState<CobranzaItem[]>([])
  const [recordatoriosMap, setRecordatoriosMap] = useState<Record<string, RecordatorioResumen>>({})
  const [cuentas, setCuentas] = useState<CuentaBancaria[]>([])
  const [usuarioRol, setUsuarioRol] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [sendingRecordatorioId, setSendingRecordatorioId] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const [selectedItem, setSelectedItem] = useState<CobranzaItem | null>(null)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [paymentForm, setPaymentForm] = useState<PaymentFormState>({
    fecha_pago: todayLocalDate(),
    cuenta_bancaria_id: '',
  })

  const canManagePayments = useMemo(() => {
    return ['admin', 'administracion_financiera', 'cobranzas', 'cobranza'].includes(
      usuarioRol
    )
  }, [usuarioRol])

  useEffect(() => {
    const syncEmpresaActiva = () => {
      const empresaId = window.localStorage.getItem(STORAGE_KEY) || ''
      setEmpresaActivaId(empresaId)
    }

    syncEmpresaActiva()
    window.addEventListener('empresa-activa-cambiada', syncEmpresaActiva)

    return () => {
      window.removeEventListener('empresa-activa-cambiada', syncEmpresaActiva)
    }
  }, [])

  const loadData = useCallback(async () => {
    if (!empresaActivaId) return

    try {
      setLoading(true)
      setError('')
      setSuccess('')

      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        setError('No hay sesión activa.')
        return
      }

      const userId = session.user.id

      const [cobranzaResp, cuentasResp, rolResp, recordatoriosResp] = await Promise.all([
        supabase
          .from('v_cobranza_pendiente')
          .select('*')
          .eq('empresa_id', empresaActivaId)
          .order('fecha_vencimiento', { ascending: true })
          .order('fecha_emision', { ascending: true }),

        supabase
          .from('cuentas_bancarias')
          .select(
            'id, empresa_id, banco, nombre_cuenta, tipo_cuenta, moneda, saldo_inicial, activa'
          )
          .eq('empresa_id', empresaActivaId)
          .eq('activa', true)
          .is('deleted_at', null)
          .order('banco', { ascending: true })
          .order('nombre_cuenta', { ascending: true }),

        supabase
          .from('usuario_empresas')
          .select('rol')
          .eq('usuario_id', userId)
          .eq('empresa_id', empresaActivaId)
          .eq('activo', true)
          .maybeSingle(),

        supabase
          .from('cobranza_recordatorios')
          .select('movimiento_id, created_at, estado')
          .eq('empresa_id', empresaActivaId)
          .order('created_at', { ascending: false }),
      ])

      if (cobranzaResp.error) {
        throw new Error(`No se pudo cargar cobranza: ${cobranzaResp.error.message}`)
      }

      if (cuentasResp.error) {
        throw new Error(
          `No se pudieron cargar las cuentas bancarias: ${cuentasResp.error.message}`
        )
      }

      if (rolResp.error) {
        throw new Error(`No se pudo resolver el rol del usuario: ${rolResp.error.message}`)
      }

      const resumenRecordatorios: Record<string, RecordatorioResumen> = {}

      if (recordatoriosResp.error) {
        console.error('No se pudo cargar historial de recordatorios:', recordatoriosResp.error.message)
      }

      for (const recordatorio of (recordatoriosResp.data ?? []) as {
        movimiento_id: string | null
        created_at: string | null
        estado: string | null
      }[]) {
        if (!recordatorio.movimiento_id) continue

        const actual = resumenRecordatorios[recordatorio.movimiento_id] || {
          total: 0,
          ultimo: null,
          ultimoEstado: null,
        }

        actual.total += 1

        if (
          recordatorio.created_at &&
          (!actual.ultimo ||
            new Date(recordatorio.created_at).getTime() >
              new Date(actual.ultimo).getTime())
        ) {
          actual.ultimo = recordatorio.created_at
          actual.ultimoEstado = recordatorio.estado
        }

        resumenRecordatorios[recordatorio.movimiento_id] = actual
      }

      setItems((cobranzaResp.data ?? []) as CobranzaItem[])
      setRecordatoriosMap(resumenRecordatorios)
      setCuentas((cuentasResp.data ?? []) as CuentaBancaria[])
      setUsuarioRol(rolResp.data?.rol || '')
      setIsAdmin((rolResp.data?.rol || '') === 'admin')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo cargar cobranza.')
    } finally {
      setLoading(false)
    }
  }, [empresaActivaId])

  useEffect(() => {
    void loadData()
  }, [loadData])

  const totalPendiente = useMemo(
    () => items.reduce((acc, item) => acc + (item.saldo_pendiente ?? 0), 0),
    [items]
  )

  const totalVencidas = useMemo(
    () => items.filter((item) => item.estado === 'vencido').length,
    [items]
  )

  const totalPendientes = useMemo(
    () =>
      items.filter((item) => item.estado === 'pendiente' || item.estado === 'parcial')
        .length,
    [items]
  )

  const openPaymentModal = (item: CobranzaItem) => {
    setSelectedItem(item)
    setPaymentForm({
      fecha_pago: todayLocalDate(),
      cuenta_bancaria_id: item.cuenta_bancaria_id || '',
    })
    setShowPaymentModal(true)
    setError('')
    setSuccess('')
  }

  const closePaymentModal = () => {
    setSelectedItem(null)
    setShowPaymentModal(false)
    setPaymentForm({
      fecha_pago: todayLocalDate(),
      cuenta_bancaria_id: '',
    })
  }

  const handleRegistrarPago = async () => {
    if (!selectedItem) {
      setError('No se seleccionó ninguna factura.')
      return
    }

    if (!paymentForm.fecha_pago) {
      setError('Debes indicar la fecha de pago.')
      return
    }

    if (!paymentForm.cuenta_bancaria_id) {
      setError('Debes seleccionar la cuenta bancaria que recibió el pago.')
      return
    }

    try {
      setSaving(true)
      setError('')
      setSuccess('')

      const {
        data: { user },
      } = await supabase.auth.getUser()

      const updatedAt = new Date().toISOString()

      const [cxcResp, movResp] = await Promise.all([
        supabase
          .from('cuentas_por_cobrar')
          .update({
            estado: 'pagado',
            saldo_pendiente: 0,
            updated_by: user?.id ?? null,
            updated_at: updatedAt,
          })
          .eq('movimiento_id', selectedItem.movimiento_id)
          .eq('empresa_id', empresaActivaId)
          .eq('activo', true)
          .is('deleted_at', null),

        supabase
          .from('movimientos')
          .update({
            estado: 'pagado',
            fecha: paymentForm.fecha_pago,
            cuenta_bancaria_id: paymentForm.cuenta_bancaria_id,
            updated_by: user?.id ?? null,
            updated_at: updatedAt,
          })
          .eq('id', selectedItem.movimiento_id)
          .eq('empresa_id', empresaActivaId)
          .eq('activo', true)
          .is('deleted_at', null),
      ])

      if (cxcResp.error) {
        throw new Error(
          `No se pudo actualizar cuentas por cobrar: ${cxcResp.error.message}`
        )
      }

      if (movResp.error) {
        throw new Error(`No se pudo actualizar el ingreso: ${movResp.error.message}`)
      }

      closePaymentModal()
      setSuccess('Pago registrado correctamente. Ya debería reflejarse en Ingresos y Bancos.')
      await loadData()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo registrar el pago.')
    } finally {
      setSaving(false)
    }
  }

  const handleEnviarRecordatorio = async (item: CobranzaItem) => {
    const confirmar = window.confirm(
      `¿Enviar recordatorio de cobranza?

Cliente: ${item.cliente || '-'}
Factura: ${item.numero_factura || '-'}
Saldo pendiente: ${item.saldo_pendiente_clp || formatCLP(item.saldo_pendiente)}

El correo se enviará inmediatamente.`
    )

    if (!confirmar) return

    try {
      setSendingRecordatorioId(item.movimiento_id)
      setError('')
      setSuccess('')

      const {
        data: { session },
      } = await supabase.auth.getSession()

      const token = session?.access_token

      if (!token) {
        throw new Error('No hay sesión activa.')
      }

      const response = await fetch('/api/cobranza/enviar-recordatorio', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          movimientoId: item.movimiento_id,
        }),
      })

      const json = await response.json()

      if (!response.ok) {
        throw new Error(json.error || 'No se pudo enviar el recordatorio.')
      }

      setSuccess(`Recordatorio enviado correctamente a ${json.destinatario || 'cliente'}.`)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo enviar el recordatorio.')
    } finally {
      setSendingRecordatorioId('')
    }
  }
  return (
    <main className="space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-3xl font-semibold text-slate-900">Cobranza</h1>
            <p className="mt-1 text-sm text-slate-500">
              Facturas pendientes, vencidas o parciales de la empresa activa.
            </p>
          </div>

          <div className="text-sm text-slate-500">
            {isAdmin ? 'Perfil administrador' : `Rol: ${usuarioRol || 'sin rol'}`}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          Cargando cobranza...
        </div>
      ) : null}

      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-red-700 shadow-sm">
          {error}
        </div>
      ) : null}

      {success ? (
        <div className="rounded-2xl border border-green-200 bg-green-50 p-6 text-green-700 shadow-sm">
          {success}
        </div>
      ) : null}

      {!loading && !error ? (
        <>
          <section className="grid gap-4 md:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <p className="text-sm text-slate-500">Monto pendiente</p>
              <p className="mt-2 text-2xl font-bold text-slate-900">
                {formatCLP(totalPendiente)}
              </p>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <p className="text-sm text-slate-500">Documentos pendientes / parciales</p>
              <p className="mt-2 text-2xl font-bold text-slate-900">{totalPendientes}</p>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <p className="text-sm text-slate-500">Documentos vencidos</p>
              <p className="mt-2 text-2xl font-bold text-slate-900">{totalVencidas}</p>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-2xl font-semibold text-slate-900">
                  Cuentas por cobrar activas
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  Registra aquí el pago de una factura para actualizar ingresos y bancos.
                </p>
              </div>

              {!canManagePayments ? (
                <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-2 text-sm text-amber-800">
                  Tu rol puede visualizar, pero no registrar pagos.
                </div>
              ) : null}
            </div>

            {items.length === 0 ? (
              <div className="mt-6 rounded-xl border border-dashed border-slate-300 bg-slate-50 p-6 text-sm text-slate-600">
                No hay facturas pendientes para la empresa activa.
              </div>
            ) : (
              <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200">
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm">
                    <thead className="bg-slate-50">
                      <tr className="text-left text-slate-600">
                        <th className="px-4 py-3 font-semibold">Cliente</th>
                        <th className="px-4 py-3 font-semibold">Factura</th>
                        <th className="px-4 py-3 font-semibold">Emisión</th>
                        <th className="px-4 py-3 font-semibold">Vencimiento</th>
                        <th className="px-4 py-3 font-semibold">Descripción</th>
                        <th className="px-4 py-3 font-semibold">Monto total</th>
                        <th className="px-4 py-3 font-semibold">Saldo pendiente</th>
                        <th className="px-4 py-3 font-semibold">Recordatorios</th>
                        <th className="px-4 py-3 font-semibold">Estado</th>
                        <th className="px-4 py-3 text-right font-semibold">Acciones</th>
                      </tr>
                    </thead>

                    <tbody>
                      {items.map((item) => (
                        <tr
                          key={item.movimiento_id}
                          className="border-t border-slate-100 text-slate-700"
                        >
                          <td className="px-4 py-3">{item.cliente || '-'}</td>
                          <td className="px-4 py-3 font-medium text-slate-900">
                            {item.numero_factura || '-'}
                          </td>
                          <td className="px-4 py-3">{formatDate(item.fecha_emision)}</td>
                          <td className="px-4 py-3">{formatDate(item.fecha_vencimiento)}</td>
                          <td className="px-4 py-3">
                            <div className="max-w-[260px] whitespace-normal break-words">
                              {item.descripcion || '-'}
                            </div>
                          </td>
                          <td className="px-4 py-3">{item.monto_total_clp || formatCLP(item.monto_total)}</td>
                          <td className="px-4 py-3">
                            {item.saldo_pendiente_clp || formatCLP(item.saldo_pendiente)}
                          </td>
                          <td className="px-4 py-3">
                            {recordatoriosMap[item.movimiento_id]?.total ? (
                              <div className="text-xs">
                                <div className="font-semibold text-slate-800">
                                  {recordatoriosMap[item.movimiento_id].total} enviado
                                  {recordatoriosMap[item.movimiento_id].total === 1 ? '' : 's'}
                                </div>
                                <div className="mt-0.5 text-slate-500">
                                  Último: {formatDateTime(recordatoriosMap[item.movimiento_id].ultimo)}
                                </div>
                              </div>
                            ) : (
                              <span className="text-xs text-slate-400">Sin recordatorios</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`inline-flex rounded-full border px-3 py-1 text-xs font-medium ${estadoBadgeClass(
                                item.estado
                              )}`}
                            >
                              {item.estado}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            {canManagePayments ? (
                              <div className="flex flex-col items-end gap-2">
                                <button
                                  type="button"
                                  onClick={() => handleEnviarRecordatorio(item)}
                                  disabled={
                                    sendingRecordatorioId === item.movimiento_id ||
                                    item.estado === 'pagado' ||
                                    Number(item.saldo_pendiente || 0) <= 0
                                  }
                                  className="inline-flex items-center justify-center rounded-lg border border-blue-300 px-3 py-1.5 text-sm font-medium text-blue-700 hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-60"
                                >
                                  {sendingRecordatorioId === item.movimiento_id
                                    ? 'Enviando...'
                                    : recordatoriosMap[item.movimiento_id]?.total
                                      ? 'Enviar nuevo recordatorio'
                                      : 'Enviar recordatorio'}
                                </button>

                                <button
                                  type="button"
                                  onClick={() => openPaymentModal(item)}
                                  className="inline-flex items-center justify-center rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-100"
                                >
                                  Registrar pago
                                </button>
                              </div>
                            ) : (
                              <span className="text-xs text-slate-400">Sin acciones</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </section>
        </>
      ) : null}

      {showPaymentModal && selectedItem ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-xl font-semibold text-slate-900">
                  Registrar pago de factura
                </h3>
                <p className="mt-1 text-sm text-slate-500">
                  Al confirmar, la factura se marcará como pagada y se reflejará en ingresos y
                  bancos.
                </p>
              </div>

              <button
                type="button"
                onClick={closePaymentModal}
                className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-100"
              >
                Cerrar
              </button>
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
                  Cliente
                </p>
                <p className="mt-1 text-sm text-slate-900">{selectedItem.cliente || '-'}</p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
                  Factura
                </p>
                <p className="mt-1 text-sm text-slate-900">
                  {selectedItem.numero_factura || '-'}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
                  Monto total
                </p>
                <p className="mt-1 text-sm text-slate-900">
                  {selectedItem.monto_total_clp || formatCLP(selectedItem.monto_total)}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
                  Saldo pendiente
                </p>
                <p className="mt-1 text-sm text-slate-900">
                  {selectedItem.saldo_pendiente_clp || formatCLP(selectedItem.saldo_pendiente)}
                </p>
              </div>
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  Fecha de pago *
                </label>
                <input
                  type="date"
                  value={paymentForm.fecha_pago}
                  onChange={(e) =>
                    setPaymentForm((prev) => ({ ...prev, fecha_pago: e.target.value }))
                  }
                  className="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none focus:border-slate-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  Cuenta bancaria *
                </label>
                <select
                  value={paymentForm.cuenta_bancaria_id}
                  onChange={(e) =>
                    setPaymentForm((prev) => ({
                      ...prev,
                      cuenta_bancaria_id: e.target.value,
                    }))
                  }
                  className="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none focus:border-slate-500"
                >
                  <option value="">Selecciona una cuenta</option>
                  {cuentas.map((cuenta) => (
                    <option key={cuenta.id} value={cuenta.id}>
                      {cuenta.banco} - {cuenta.nombre_cuenta}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={closePaymentModal}
                className="inline-flex items-center justify-center rounded-xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100"
              >
                Cancelar
              </button>

              <button
                type="button"
                onClick={handleRegistrarPago}
                disabled={saving}
                className="inline-flex items-center justify-center rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70"
              >
                {saving ? 'Registrando pago...' : 'Confirmar pago'}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  )
}

export default function CobranzaPage() {
  return (
    <ProtectedModuleRoute moduleKey="cobranza">
      <CobranzaPageContent />
    </ProtectedModuleRoute>
  )
}