'use client'

import { useEffect, useMemo, useState } from 'react'
import ProtectedModuleRoute from '@/components/ProtectedModuleRoute'
import { supabase } from '@/lib/supabase/client'

const STORAGE_ID_KEY = 'empresa_activa_id'
const STORAGE_NAME_KEY = 'empresa_activa_nombre'

type TipoRegistro = 'compras' | 'ventas'
type EstadoDocumento =
  | 'pendiente'
  | 'convertido'
  | 'solo_documental'
  | 'omitido'
  | 'vinculado'
  | 'anulado'

type SiiDocumentoCsv = {
  tipo_doc_codigo: number
  tipo_doc_nombre: string
  tipo_compra_venta: string | null
  rut_tercero: string | null
  razon_social: string | null
  folio: string
  fecha_docto: string | null
  fecha_recepcion: string | null
  fecha_acuse: string | null
  monto_exento: number
  monto_neto: number
  monto_iva_recuperable: number
  monto_iva_no_recuperable: number
  monto_iva: number
  monto_total: number
  monto_neto_activo_fijo: number
  iva_activo_fijo: number
  iva_uso_comun: number
  impuesto_sin_derecho_credito: number
  codigo_otro_impuesto: string | null
  valor_otro_impuesto: number
  tasa_otro_impuesto: number | null
  accion_sugerida: string
  raw_data: Record<string, string>
}

type SiiDocumento = {
  id: string
  empresa_id: string
  importacion_id: string | null
  tipo_registro: TipoRegistro
  tipo_doc_codigo: number
  tipo_doc_nombre: string
  tipo_compra_venta: string | null
  rut_tercero: string | null
  razon_social: string | null
  folio: string
  fecha_docto: string | null
  fecha_recepcion: string | null
  monto_exento: number | string | null
  monto_neto: number | string | null
  monto_iva_recuperable: number | string | null
  monto_iva_no_recuperable: number | string | null
  monto_iva: number | string | null
  monto_total: number | string | null
  accion_sugerida: string
  estado: EstadoDocumento
  proveedor_id: string | null
  cliente_id: string | null
  movimiento_id: string | null
  observaciones: string | null
  xml_importado: boolean | null
  xml_nombre_archivo: string | null
  xml_importado_at: string | null
  descripcion_xml: string | null
  detalle_items_xml: Array<Record<string, unknown>> | null
  created_at: string
}


type CategoriaBasica = {
  id: string
  nombre: string
  tipo: string | null
}

type CentroCostoBasico = {
  id: string
  nombre: string
}

type TerceroBasico = {
  id: string
  nombre: string
  rut: string | null
  condicion_pago: string | null
  dias_credito: number | null
}

type CuentaBancariaBasica = {
  id: string
  banco: string
  nombre_cuenta: string
}

type ReviewFormState = {
  descripcion: string
  tercero_id: string
  categoria_id: string
  centro_costo_id: string
  estado_pago: 'pendiente' | 'pagado'
  fecha_vencimiento: string
  cuenta_bancaria_id: string
}

const EMPTY_REVIEW_FORM: ReviewFormState = {
  descripcion: '',
  tercero_id: '',
  categoria_id: '',
  centro_costo_id: '',
  estado_pago: 'pendiente',
  fecha_vencimiento: '',
  cuenta_bancaria_id: '',
}
const TIPO_DOC_LABELS: Record<number, string> = {
  30: 'Factura',
  33: 'Factura electrónica',
  34: 'Factura exenta electrónica',
  46: 'Factura de compra electrónica',
  52: 'Guía de despacho electrónica',
  56: 'Nota de débito electrónica',
  61: 'Nota de crédito electrónica',
}

const ESTADO_LABELS: Record<string, string> = {
  pendiente: 'Pendiente',
  convertido: 'Convertido',
  solo_documental: 'Solo documental',
  omitido: 'Omitido',
  vinculado: 'Vinculado',
  anulado: 'Anulado',
}

const ACCION_LABELS: Record<string, string> = {
  crear_egreso: 'Crear egreso',
  crear_ingreso: 'Crear ingreso',
  ajuste_negativo: 'Ajuste negativo',
  ajuste_positivo: 'Ajuste positivo',
  solo_documental: 'Solo documental',
  revisar: 'Revisar',
}

function toNumber(value: number | string | null | undefined) {
  if (typeof value === 'number') return value
  if (typeof value === 'string') {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : 0
  }
  return 0
}

function formatCurrency(value: number | string | null | undefined) {
  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    maximumFractionDigits: 0,
  }).format(toNumber(value))
}

function formatDate(value: string | null | undefined) {
  if (!value) return '-'

  const date = new Date(`${value}T00:00:00`)
  if (Number.isNaN(date.getTime())) return '-'

  return new Intl.DateTimeFormat('es-CL', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date)
}

function sumarDiasFecha(fechaBase: string | null | undefined, dias: number) {
  if (!fechaBase) return ''

  const date = new Date(`${fechaBase}T00:00:00`)
  if (Number.isNaN(date.getTime())) return fechaBase

  date.setDate(date.getDate() + dias)
  return date.toISOString().slice(0, 10)
}

function getDiasCreditoTercero(tercero: TerceroBasico | undefined) {
  if (!tercero) return 0

  switch (tercero.condicion_pago || 'contado') {
    case 'contado':
      return 0
    case '7_dias':
      return 7
    case '15_dias':
      return 15
    case '30_dias':
      return 30
    case '45_dias':
      return 45
    case '60_dias':
      return 60
    case 'personalizado':
      return Math.max(0, Math.trunc(Number(tercero.dias_credito || 0)))
    default:
      return Math.max(0, Math.trunc(Number(tercero.dias_credito || 0)))
  }
}

function getCondicionPagoLabel(tercero: TerceroBasico | undefined) {
  if (!tercero) return ''

  if ((tercero.condicion_pago || 'contado') === 'personalizado') {
    return `Personalizado (${tercero.dias_credito || 0} días)`
  }

  switch (tercero.condicion_pago || 'contado') {
    case 'contado':
      return 'Contado'
    case '7_dias':
      return '7 días'
    case '15_dias':
      return '15 días'
    case '30_dias':
      return '30 días'
    case '45_dias':
      return '45 días'
    case '60_dias':
      return '60 días'
    default:
      return 'Contado'
  }
}

function calcularFechaVencimientoSugerida(
  documento: SiiDocumento,
  tercero: TerceroBasico | undefined
) {
  const fechaBase = documento.fecha_docto || todayLocalDate()
  return sumarDiasFecha(fechaBase, getDiasCreditoTercero(tercero))
}

function getEstadoClass(estado: string) {
  switch (estado) {
    case 'pendiente':
      return 'border-blue-200 bg-blue-50 text-blue-700'
    case 'convertido':
      return 'border-emerald-200 bg-emerald-50 text-emerald-700'
    case 'solo_documental':
      return 'border-slate-200 bg-slate-50 text-slate-700'
    case 'omitido':
      return 'border-amber-200 bg-amber-50 text-amber-700'
    case 'vinculado':
      return 'border-purple-200 bg-purple-50 text-purple-700'
    case 'anulado':
      return 'border-rose-200 bg-rose-50 text-rose-700'
    default:
      return 'border-slate-200 bg-slate-50 text-slate-700'
  }
}

function getAccionClass(accion: string) {
  switch (accion) {
    case 'crear_egreso':
    case 'crear_ingreso':
      return 'border-emerald-200 bg-emerald-50 text-emerald-700'
    case 'ajuste_negativo':
      return 'border-rose-200 bg-rose-50 text-rose-700'
    case 'ajuste_positivo':
      return 'border-amber-200 bg-amber-50 text-amber-700'
    case 'solo_documental':
      return 'border-slate-200 bg-slate-50 text-slate-700'
    default:
      return 'border-blue-200 bg-blue-50 text-blue-700'
  }
}


function getAccionVisualLabel(doc: SiiDocumento) {
  if (doc.estado === 'convertido') {
    if (doc.accion_sugerida === 'ajuste_negativo') return 'Ajuste negativo creado'
    if (doc.accion_sugerida === 'ajuste_positivo') return 'Ajuste positivo creado'

    return doc.tipo_registro === 'ventas' ? 'Ingreso creado' : 'Egreso creado'
  }

  if (doc.estado === 'vinculado') {
    return 'Movimiento vinculado'
  }

  if (doc.estado === 'solo_documental') {
    return 'Solo documental'
  }

  return ACCION_LABELS[doc.accion_sugerida] || doc.accion_sugerida
}

function getAccionVisualClass(doc: SiiDocumento) {
  if (doc.estado === 'convertido') {
    return 'border-emerald-200 bg-emerald-50 text-emerald-700'
  }

  if (doc.estado === 'vinculado') {
    return 'border-purple-200 bg-purple-50 text-purple-700'
  }

  return getAccionClass(doc.accion_sugerida)
}
function getTipoDocNombre(codigo: number, nombre: string | null | undefined) {
  return nombre || TIPO_DOC_LABELS[codigo] || `Tipo ${codigo}`
}


function parseCsvLine(line: string) {
  const values: string[] = []
  let current = ''
  let inQuotes = false

  for (let i = 0; i < line.length; i += 1) {
    const char = line[i]
    const nextChar = line[i + 1]

    if (char === '"' && inQuotes && nextChar === '"') {
      current += '"'
      i += 1
      continue
    }

    if (char === '"') {
      inQuotes = !inQuotes
      continue
    }

    if (char === ';' && !inQuotes) {
      values.push(current.trim())
      current = ''
      continue
    }

    current += char
  }

  values.push(current.trim())
  return values
}

function parseCsv(text: string) {
  const cleanText = text.replace(/^\uFEFF/, '')
  const lines = cleanText
    .split(/\r?\n/)
    .map((line) => line.trimEnd())
    .filter((line) => line.trim().length > 0)

  if (lines.length <= 1) return []

  const headers = parseCsvLine(lines[0]).map((header) => header.trim())

  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line)
    const row: Record<string, string> = {}

    headers.forEach((header, index) => {
      row[header] = values[index]?.trim() || ''
    })

    return row
  })
}

function parseSiiNumber(value: string | number | null | undefined) {
  if (typeof value === 'number') return value

  const clean = String(value ?? '')
    .trim()
    .replace(/\./g, '')
    .replace(/,/g, '.')

  if (!clean) return 0

  const parsed = Number(clean)
  return Number.isFinite(parsed) ? parsed : 0
}

function parseSiiDate(value: string | null | undefined) {
  const clean = String(value ?? '').trim()
  if (!clean) return null

  const [day, month, year] = clean.split('/')

  if (!day || !month || !year) return null

  return `${year.padStart(4, '0')}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`
}

function parseSiiDateTime(value: string | null | undefined) {
  const clean = String(value ?? '').trim()
  if (!clean) return null

  const [datePart, timePart = '00:00:00'] = clean.split(' ')
  const date = parseSiiDate(datePart)

  if (!date) return null

  return `${date}T${timePart}`
}

function getSiiTipoDocNombre(codigo: number) {
  return TIPO_DOC_LABELS[codigo] || `Tipo ${codigo}`
}

function getAccionSugeridaCompras(tipoDoc: number) {
  if ([33, 34, 46].includes(tipoDoc)) return 'crear_egreso'
  if (tipoDoc === 61) return 'ajuste_negativo'
  if (tipoDoc === 56) return 'ajuste_positivo'
  if (tipoDoc === 52) return 'solo_documental'

  return 'revisar'
}

function parseSiiComprasCsv(text: string): SiiDocumentoCsv[] {
  const rows = parseCsv(text)

  return rows
    .map((row) => {
      const tipoDoc = Math.trunc(parseSiiNumber(row['Tipo Doc']))
      const ivaRecuperable = parseSiiNumber(row['Monto IVA Recuperable'])
      const ivaNoRecuperable = parseSiiNumber(row['Monto Iva No Recuperable'])

      return {
        tipo_doc_codigo: tipoDoc,
        tipo_doc_nombre: getSiiTipoDocNombre(tipoDoc),
        tipo_compra_venta: row['Tipo Compra'] || null,
        rut_tercero: row['RUT Proveedor'] || null,
        razon_social: row['Razon Social'] || null,
        folio: row['Folio'] || '',
        fecha_docto: parseSiiDate(row['Fecha Docto']),
        fecha_recepcion: parseSiiDateTime(row['Fecha Recepcion']),
        fecha_acuse: parseSiiDateTime(row['Fecha Acuse']),
        monto_exento: parseSiiNumber(row['Monto Exento']),
        monto_neto: parseSiiNumber(row['Monto Neto']),
        monto_iva_recuperable: ivaRecuperable,
        monto_iva_no_recuperable: ivaNoRecuperable,
        monto_iva: ivaRecuperable + ivaNoRecuperable,
        monto_total: parseSiiNumber(row['Monto Total']),
        monto_neto_activo_fijo: parseSiiNumber(row['Monto Neto Activo Fijo']),
        iva_activo_fijo: parseSiiNumber(row['IVA Activo Fijo']),
        iva_uso_comun: parseSiiNumber(row['IVA uso Comun']),
        impuesto_sin_derecho_credito: parseSiiNumber(row['Impto. Sin Derecho a Credito']),
        codigo_otro_impuesto: row['Codigo Otro Impuesto'] || null,
        valor_otro_impuesto: parseSiiNumber(row['Valor Otro Impuesto']),
        tasa_otro_impuesto: row['Tasa Otro Impuesto']
          ? parseSiiNumber(row['Tasa Otro Impuesto'])
          : null,
        accion_sugerida: getAccionSugeridaCompras(tipoDoc),
        raw_data: row,
      }
    })
    .filter((row) => row.tipo_doc_codigo && row.folio)
}


function normalizeCsvKey(value: string) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
}

function getCsvValueFlexible(row: Record<string, string>, keys: string[]) {
  const normalized = new Map<string, string>()

  for (const [key, value] of Object.entries(row)) {
    normalized.set(normalizeCsvKey(key), value)
  }

  for (const key of keys) {
    const value = normalized.get(normalizeCsvKey(key))

    if (value != null && value !== '') {
      return value
    }
  }

  return ''
}

function getAccionSugeridaVentas(tipoDoc: number) {
  if ([33, 34, 39, 41].includes(tipoDoc)) return 'crear_ingreso'
  if (tipoDoc === 61) return 'ajuste_negativo'
  if (tipoDoc === 56) return 'ajuste_positivo'
  if (tipoDoc === 52) return 'solo_documental'

  return 'revisar'
}
function parseSiiVentasCsv(text: string): SiiDocumentoCsv[] {
  const rows = parseCsv(text)

  return rows
    .map((row) => {
      const tipoDoc = Math.trunc(
        parseSiiNumber(
          getCsvValueFlexible(row, ['Tipo Doc', 'Tipo Docto', 'Tipo Documento'])
        )
      )

      const montoIva = parseSiiNumber(
        getCsvValueFlexible(row, [
          'Monto IVA',
          'Monto Iva',
          'IVA',
          'Iva',
          'Monto IVA Recuperable',
        ])
      )

      return {
        tipo_doc_codigo: tipoDoc,
        tipo_doc_nombre: getSiiTipoDocNombre(tipoDoc),
        tipo_compra_venta:
          getCsvValueFlexible(row, ['Tipo Venta', 'Tipo', 'Tipo Compra']) || null,
        rut_tercero:
          getCsvValueFlexible(row, [
            'RUT Cliente',
            'Rut Cliente',
            'RUT Receptor',
            'Rut Receptor',
          ]) || null,
        razon_social:
          getCsvValueFlexible(row, [
            'Razon Social',
            'Razón Social',
            'Razon Social Receptor',
            'Cliente',
          ]) || null,
        folio:
          getCsvValueFlexible(row, ['Folio', 'Nro Documento', 'Número Documento']) ||
          '',
        fecha_docto: parseSiiDate(
          getCsvValueFlexible(row, [
            'Fecha Docto',
            'Fecha Documento',
            'Fecha Emision',
            'Fecha Emisión',
          ])
        ),
        fecha_recepcion: parseSiiDateTime(
          getCsvValueFlexible(row, ['Fecha Recepcion', 'Fecha Recepción'])
        ),
        fecha_acuse: parseSiiDateTime(getCsvValueFlexible(row, ['Fecha Acuse'])),
        monto_exento: parseSiiNumber(
          getCsvValueFlexible(row, [
            'Monto Exento',
            'Monto exento',
            'Monto Exento/No Afecto',
            'Monto Exento No Afecto',
            'Monto No Afecto',
          ])
        ),
        monto_neto: parseSiiNumber(
          getCsvValueFlexible(row, ['Monto Neto', 'Monto neto', 'Neto'])
        ),
        monto_iva_recuperable: montoIva,
        monto_iva_no_recuperable: 0,
        monto_iva: montoIva,
        monto_total: parseSiiNumber(
          getCsvValueFlexible(row, [
            'Monto Total',
            'Monto total',
            'Total',
            'Total Documento',
          ])
        ),
        monto_neto_activo_fijo: 0,
        iva_activo_fijo: 0,
        iva_uso_comun: 0,
        impuesto_sin_derecho_credito: 0,
        codigo_otro_impuesto:
          getCsvValueFlexible(row, ['Codigo Otro Impuesto', 'Código Otro Impuesto']) ||
          null,
        valor_otro_impuesto: parseSiiNumber(
          getCsvValueFlexible(row, ['Valor Otro Impuesto'])
        ),
        tasa_otro_impuesto: getCsvValueFlexible(row, ['Tasa Otro Impuesto'])
          ? parseSiiNumber(getCsvValueFlexible(row, ['Tasa Otro Impuesto']))
          : null,
        accion_sugerida: getAccionSugeridaVentas(tipoDoc),
        raw_data: row,
      }
    })
    .filter((row) => row.tipo_doc_codigo && row.folio)
}
function getPeriodoFromFileName(fileName: string) {
  const match = fileName.match(/_(\d{6})\.csv$/i)
  return match?.[1] || null
}


function normalizeRutSii(value: string | null | undefined) {
  return String(value ?? '')
    .replace(/\./g, '')
    .replace(/-/g, '')
    .replace(/\s+/g, '')
    .toUpperCase()
}

function amountsAreClose(a: number | string | null | undefined, b: number | string | null | undefined) {
  return Math.abs(Math.abs(toNumber(a)) - Math.abs(toNumber(b))) <= 1
}

function getDescripcionSugerida(doc: SiiDocumento) {
  if (doc.descripcion_xml?.trim()) {
    return doc.descripcion_xml.trim()
  }

  const tipo = getTipoDocNombre(doc.tipo_doc_codigo, doc.tipo_doc_nombre)
  const tercero = doc.razon_social || 'Sin tercero'
  const registro = doc.tipo_registro === 'ventas' ? 'venta' : 'compra'

  return `${tipo} ${registro} SII N° ${doc.folio} - ${tercero}`
}

type XmlDteItem = {
  numero_linea: number
  nombre_item: string
  descripcion_item: string
  cantidad: number | null
  precio_unitario: number | null
  monto_item: number
}

type XmlDteDoc = {
  tipo_doc_codigo: number
  folio: string
  rut_emisor: string
  rut_receptor: string
  razon_social_emisor: string
  razon_social_receptor: string
  fecha_emision: string | null
  monto_total: number
  descripcion_xml: string
  detalle_items_xml: XmlDteItem[]
}

function getChildrenByLocalName(node: Element | Document, localName: string) {
  return Array.from(node.getElementsByTagName('*')).filter(
    (item) => item.localName === localName
  ) as Element[]
}

function getFirstByLocalName(node: Element | Document, localName: string) {
  return getChildrenByLocalName(node, localName)[0] || null
}

function getXmlText(node: Element | Document, localName: string) {
  return getFirstByLocalName(node, localName)?.textContent?.trim() || ''
}

function parseXmlNumber(value: string | null | undefined) {
  const clean = String(value ?? '')
    .trim()
    .replace(/\./g, '')
    .replace(/,/g, '.')

  if (!clean) return 0

  const parsed = Number(clean)
  return Number.isFinite(parsed) ? parsed : 0
}

function buildDescripcionXml(items: XmlDteItem[]) {
  const partes = items
    .map((item) => {
      const nombre = item.nombre_item?.trim()
      const descripcion = item.descripcion_item?.trim()

      if (nombre && descripcion && descripcion !== nombre) {
        return `${nombre} - ${descripcion}`
      }

      return nombre || descripcion
    })
    .filter(Boolean)

  if (partes.length === 0) return ''

  return partes.slice(0, 5).join('; ')
}

function parseDteXml(text: string): XmlDteDoc[] {
  const parser = new DOMParser()
  const xml = parser.parseFromString(text, 'application/xml')

  const parserError = xml.getElementsByTagName('parsererror')[0]
  if (parserError) {
    throw new Error('El archivo XML no tiene un formato válido.')
  }

  const dtes = getChildrenByLocalName(xml, 'DTE')

  return dtes
    .map((dte) => {
      const documento = getFirstByLocalName(dte, 'Documento') || dte
      const encabezado = getFirstByLocalName(documento, 'Encabezado') || documento
      const idDoc = getFirstByLocalName(encabezado, 'IdDoc') || encabezado
      const emisor = getFirstByLocalName(encabezado, 'Emisor') || encabezado
      const receptor = getFirstByLocalName(encabezado, 'Receptor') || encabezado
      const totales = getFirstByLocalName(encabezado, 'Totales') || encabezado

      const detalles = getChildrenByLocalName(documento, 'Detalle')

      const detalleItems = detalles.map((detalle, index) => ({
        numero_linea: parseXmlNumber(getXmlText(detalle, 'NroLinDet')) || index + 1,
        nombre_item: getXmlText(detalle, 'NmbItem'),
        descripcion_item: getXmlText(detalle, 'DscItem'),
        cantidad: getXmlText(detalle, 'QtyItem')
          ? parseXmlNumber(getXmlText(detalle, 'QtyItem'))
          : null,
        precio_unitario: getXmlText(detalle, 'PrcItem')
          ? parseXmlNumber(getXmlText(detalle, 'PrcItem'))
          : null,
        monto_item: parseXmlNumber(getXmlText(detalle, 'MontoItem')),
      }))

      const tipoDoc = Math.trunc(parseXmlNumber(getXmlText(idDoc, 'TipoDTE')))
      const folio = getXmlText(idDoc, 'Folio')

      return {
        tipo_doc_codigo: tipoDoc,
        folio,
        rut_emisor: getXmlText(emisor, 'RUTEmisor'),
        rut_receptor: getXmlText(receptor, 'RUTRecep'),
        razon_social_emisor: getXmlText(emisor, 'RznSoc'),
        razon_social_receptor: getXmlText(receptor, 'RznSocRecep'),
        fecha_emision: getXmlText(idDoc, 'FchEmis') || null,
        monto_total: parseXmlNumber(getXmlText(totales, 'MntTotal')),
        descripcion_xml: buildDescripcionXml(detalleItems),
        detalle_items_xml: detalleItems,
      }
    })
    .filter((doc) => doc.tipo_doc_codigo && doc.folio)
}


function todayLocalDate() {
  const now = new Date()
  const year = now.getFullYear()
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const day = String(now.getDate()).padStart(2, '0')

  return `${year}-${month}-${day}`
}

function getMovimientoTipoDocumento(codigo: number) {
  if (codigo === 61) return 'nota_credito'
  if (codigo === 56) return 'nota_debito'
  if (codigo === 52) return 'guia_despacho'
  if (codigo === 34) return 'factura_exenta'

  return 'factura'
}

function getTratamientoTributarioFromDoc(doc: SiiDocumento) {
  const iva = Math.abs(toNumber(doc.monto_iva))
  const neto = Math.abs(toNumber(doc.monto_neto))
  const exento = Math.abs(toNumber(doc.monto_exento))

  if (iva > 0 || neto > 0) return 'iva'
  if (exento > 0) return 'exento'

  return 'exento'
}

function getMovimientoLabelFromDoc(doc: SiiDocumento) {
  if (doc.accion_sugerida === 'ajuste_negativo') return 'Crear ajuste negativo'
  if (doc.accion_sugerida === 'ajuste_positivo') return 'Crear ajuste positivo'
  if (doc.tipo_registro === 'ventas') return 'Crear ingreso'
  if (doc.tipo_registro === 'compras') return 'Crear egreso'

  return 'Crear movimiento'
}

function getMovimientoTipoFromDoc(doc: SiiDocumento) {
  return doc.tipo_registro === 'ventas' ? 'ingreso' : 'egreso'
}

function getSignedAmountForDoc(doc: SiiDocumento, value: number | string | null | undefined) {
  const amount = toNumber(value)
  const factor = doc.accion_sugerida === 'ajuste_negativo' ? -1 : 1

  return amount * factor
}

function getAjusteSiiInfo(doc: SiiDocumento) {
  if (doc.tipo_doc_codigo === 61) {
    return {
      title: 'Nota de crédito',
      message:
        doc.tipo_registro === 'ventas'
          ? 'Este documento rebajará un ingreso o cuenta por cobrar. Se creará como ajuste negativo de ingreso.'
          : 'Este documento rebajará un egreso o cuenta por pagar. Se creará como ajuste negativo de egreso.',
      className: 'border-rose-200 bg-rose-50 text-rose-800',
    }
  }

  if (doc.tipo_doc_codigo === 56) {
    return {
      title: 'Nota de débito',
      message:
        doc.tipo_registro === 'ventas'
          ? 'Este documento aumentará un ingreso o cuenta por cobrar. Se creará como ajuste positivo de ingreso.'
          : 'Este documento aumentará un egreso o cuenta por pagar. Se creará como ajuste positivo de egreso.',
      className: 'border-amber-200 bg-amber-50 text-amber-800',
    }
  }

  return null
}
function DocumentosSiiPageContent() {
  const [empresaId, setEmpresaId] = useState('')
  const [empresaNombre, setEmpresaNombre] = useState('')
  const [documentos, setDocumentos] = useState<SiiDocumento[]>([])

  const [loading, setLoading] = useState(true)
  const [importing, setImporting] = useState(false)
  const [importingXml, setImportingXml] = useState(false)
  const [creatingMovimiento, setCreatingMovimiento] = useState(false)
  const [linkingExistingDocs, setLinkingExistingDocs] = useState(false)
  const [linkingExistingIngresos, setLinkingExistingIngresos] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const [q, setQ] = useState('')
  const [tipoRegistro, setTipoRegistro] = useState('')
  const [estado, setEstado] = useState('')
  const [tipoDoc, setTipoDoc] = useState('')

  const [selectedDocumento, setSelectedDocumento] = useState<SiiDocumento | null>(null)
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [reviewForm, setReviewForm] = useState<ReviewFormState>(EMPTY_REVIEW_FORM)

  const [categorias, setCategorias] = useState<CategoriaBasica[]>([])
  const [centrosCosto, setCentrosCosto] = useState<CentroCostoBasico[]>([])
  const [proveedores, setProveedores] = useState<TerceroBasico[]>([])
  const [clientes, setClientes] = useState<TerceroBasico[]>([])
  const [cuentasBancarias, setCuentasBancarias] = useState<CuentaBancariaBasica[]>([])

  useEffect(() => {
    const syncEmpresa = () => {
      setEmpresaId(window.localStorage.getItem(STORAGE_ID_KEY) || '')
      setEmpresaNombre(window.localStorage.getItem(STORAGE_NAME_KEY) || '')
    }

    syncEmpresa()
    window.addEventListener('empresa-activa-cambiada', syncEmpresa)

    return () => {
      window.removeEventListener('empresa-activa-cambiada', syncEmpresa)
    }
  }, [])


  const loadAuxData = async () => {
    if (!empresaId) {
      setCategorias([])
      setCentrosCosto([])
      setProveedores([])
      setClientes([])
      setCuentasBancarias([])
      return
    }

    const [
      categoriasResp,
      centrosResp,
      proveedoresResp,
      clientesResp,
      cuentasResp,
    ] = await Promise.all([
      supabase
        .from('categorias')
        .select('id, nombre, tipo')
        .eq('empresa_id', empresaId)
        .order('nombre', { ascending: true }),

      supabase
        .from('centros_costo')
        .select('id, nombre')
        .eq('empresa_id', empresaId)
        .order('nombre', { ascending: true }),

      supabase
        .from('proveedores')
        .select('id, nombre, rut, condicion_pago, dias_credito')
        .eq('empresa_id', empresaId)
        .eq('activo', true)
        .order('nombre', { ascending: true }),

      supabase
        .from('clientes')
        .select('id, nombre, rut, condicion_pago, dias_credito')
        .eq('empresa_id', empresaId)
        .eq('activo', true)
        .order('nombre', { ascending: true }),

      supabase
        .from('cuentas_bancarias')
        .select('id, banco, nombre_cuenta')
        .eq('empresa_id', empresaId)
        .eq('activa', true)
        .order('banco', { ascending: true })
        .order('nombre_cuenta', { ascending: true }),
    ])

    if (!categoriasResp.error) {
      setCategorias((categoriasResp.data ?? []) as CategoriaBasica[])
    }

    if (!centrosResp.error) {
      setCentrosCosto((centrosResp.data ?? []) as CentroCostoBasico[])
    }

    if (!proveedoresResp.error) {
      setProveedores((proveedoresResp.data ?? []) as TerceroBasico[])
    }

    if (!clientesResp.error) {
      setClientes((clientesResp.data ?? []) as TerceroBasico[])
    }

    if (!cuentasResp.error) {
      setCuentasBancarias((cuentasResp.data ?? []) as CuentaBancariaBasica[])
    }
  }
  const loadDocumentos = async () => {
    if (!empresaId) {
      setDocumentos([])
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError('')

      const { data, error: docsError } = await supabase
        .from('sii_documentos')
        .select('*')
        .eq('empresa_id', empresaId)
        .order('fecha_docto', { ascending: false })
        .order('created_at', { ascending: false })

      if (docsError) {
        throw new Error(docsError.message)
      }

      setDocumentos((data ?? []) as SiiDocumento[])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudieron cargar los documentos SII.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void loadDocumentos()
    void loadAuxData()
  }, [empresaId])

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase()

    return documentos.filter((doc) => {
      const matchesTipoRegistro = tipoRegistro
        ? doc.tipo_registro === tipoRegistro
        : true

      const matchesEstado = estado ? doc.estado === estado : true

      const matchesTipoDoc = tipoDoc
        ? String(doc.tipo_doc_codigo) === tipoDoc
        : true

      const matchesQ = term
        ? [
            doc.rut_tercero || '',
            doc.razon_social || '',
            doc.folio || '',
            doc.tipo_doc_nombre || '',
            String(doc.tipo_doc_codigo || ''),
          ]
            .join(' ')
            .toLowerCase()
            .includes(term)
        : true

      return matchesTipoRegistro && matchesEstado && matchesTipoDoc && matchesQ
    })
  }, [documentos, q, tipoRegistro, estado, tipoDoc])

  const resumen = useMemo(() => {
    return filtered.reduce(
      (acc, doc) => {
        acc.total += 1
        acc.montoTotal += toNumber(doc.monto_total)

        if (doc.tipo_registro === 'compras') acc.compras += 1
        if (doc.tipo_registro === 'ventas') acc.ventas += 1
        if (doc.estado === 'pendiente') acc.pendientes += 1
        if (doc.accion_sugerida === 'solo_documental') acc.documentales += 1
        if (doc.tipo_doc_codigo === 61) acc.notasCredito += 1
        if (doc.tipo_doc_codigo === 52) acc.guias += 1

        return acc
      },
      {
        total: 0,
        compras: 0,
        ventas: 0,
        pendientes: 0,
        documentales: 0,
        notasCredito: 0,
        guias: 0,
        montoTotal: 0,
      }
    )
  }, [filtered])

  const tiposDisponibles = useMemo(() => {
    const set = new Set<number>()

    documentos.forEach((doc) => {
      if (doc.tipo_doc_codigo) set.add(doc.tipo_doc_codigo)
    })

    return Array.from(set).sort((a, b) => a - b)
  }, [documentos])

  const autoVincularConEgresosExistentes = async (showLoading = false) => {
    try {
      if (!empresaId) return 0

      if (showLoading) {
        setLinkingExistingDocs(true)
      }

      const { data: documentosData, error: documentosError } = await supabase
        .from('sii_documentos')
        .select('id, tipo_doc_codigo, rut_tercero, folio, monto_total, estado, movimiento_id')
        .eq('empresa_id', empresaId)
        .eq('tipo_registro', 'compras')
        .in('estado', ['pendiente', 'solo_documental'])
        .is('movimiento_id', null)

      if (documentosError) {
        throw new Error(`No se pudieron cargar documentos SII para vincular: ${documentosError.message}`)
      }

      const documentosPendientes = ((documentosData ?? []) as {
        id: string
        tipo_doc_codigo: number
        rut_tercero: string | null
        folio: string
        monto_total: number | string | null
        estado: string
        movimiento_id: string | null
      }[]).filter((doc) => [33, 34, 46, 56, 61].includes(Number(doc.tipo_doc_codigo)))

      if (documentosPendientes.length === 0) {
        return 0
      }

      const { data: proveedoresData, error: proveedoresError } = await supabase
        .from('proveedores')
        .select('id, rut')
        .eq('empresa_id', empresaId)
        .eq('activo', true)
        .is('deleted_at', null)

      if (proveedoresError) {
        throw new Error(`No se pudieron cargar proveedores: ${proveedoresError.message}`)
      }

      const proveedorPorRut = new Map<string, string>()

      for (const proveedor of (proveedoresData ?? []) as { id: string; rut: string | null }[]) {
        const rutNormalizado = normalizeRutSii(proveedor.rut)

        if (rutNormalizado) {
          proveedorPorRut.set(rutNormalizado, proveedor.id)
        }
      }

      const documentosConProveedor = documentosPendientes
        .map((doc) => ({
          ...doc,
          proveedor_id: proveedorPorRut.get(normalizeRutSii(doc.rut_tercero)) || null,
        }))
        .filter((doc) => doc.proveedor_id)

      if (documentosConProveedor.length === 0) {
        return 0
      }

      const proveedorIds = Array.from(
        new Set(documentosConProveedor.map((doc) => doc.proveedor_id as string))
      )

      const folios = Array.from(
        new Set(documentosConProveedor.map((doc) => String(doc.folio || '').trim()).filter(Boolean))
      )

      if (proveedorIds.length === 0 || folios.length === 0) {
        return 0
      }

      const { data: movimientosData, error: movimientosError } = await supabase
        .from('movimientos')
        .select('id, proveedor_id, numero_documento, monto_total, tipo_documento')
        .eq('empresa_id', empresaId)
        .eq('tipo_movimiento', 'egreso')
        .eq('activo', true)
        .is('deleted_at', null)
        .in('proveedor_id', proveedorIds)
        .in('numero_documento', folios)

      if (movimientosError) {
        throw new Error(`No se pudieron cargar egresos existentes: ${movimientosError.message}`)
      }

      const movimientos = (movimientosData ?? []) as {
        id: string
        proveedor_id: string | null
        numero_documento: string | null
        monto_total: number | string | null
        tipo_documento: string | null
      }[]

      let vinculados = 0

      for (const doc of documentosConProveedor) {
        const candidatos = movimientos.filter(
          (mov) =>
            mov.proveedor_id === doc.proveedor_id &&
            String(mov.numero_documento || '').trim() === String(doc.folio || '').trim()
        )

        const matchPorMonto =
          candidatos.find((mov) => amountsAreClose(mov.monto_total, doc.monto_total)) || null

        const match = matchPorMonto || (candidatos.length === 1 ? candidatos[0] : null)

        if (!match) continue

        const { error: updateError } = await supabase
          .from('sii_documentos')
          .update({
            estado: 'vinculado',
            accion_sugerida: 'revisar',
            movimiento_id: match.id,
            proveedor_id: doc.proveedor_id,
            updated_at: new Date().toISOString(),
          })
          .eq('id', doc.id)
          .eq('empresa_id', empresaId)

        if (updateError) {
          throw new Error(`No se pudo vincular documento SII ${doc.folio}: ${updateError.message}`)
        }

        vinculados += 1
      }

      return vinculados
    } finally {
      if (showLoading) {
        setLinkingExistingDocs(false)
      }
    }
  }

  const handleVincularEgresosExistentes = async () => {
    try {
      setError('')
      setSuccess('')

      const vinculados = await autoVincularConEgresosExistentes(true)

      setSuccess(
        vinculados > 0
          ? `Se vincularon ${vinculados} documento${vinculados === 1 ? '' : 's'} SII con egresos existentes.`
          : 'No se encontraron documentos SII pendientes que coincidan con egresos existentes.'
      )

      await loadDocumentos()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudieron vincular egresos existentes.')
    }
  }
  const handleImportCsv = async (file: File | null) => {
    if (!file) return

    try {
      if (!empresaId) {
        throw new Error('No hay empresa activa seleccionada.')
      }

      setImporting(true)
      setError('')
      setSuccess('')

      const text = await file.text()
      const documentosCsv = parseSiiComprasCsv(text)

      if (documentosCsv.length === 0) {
        throw new Error('No se encontraron documentos válidos en el CSV.')
      }

      const { data: userData } = await supabase.auth.getUser()
      const userId = userData.user?.id || null

      const { data: existentesData, error: existentesError } = await supabase
        .from('sii_documentos')
        .select('tipo_doc_codigo, rut_tercero, folio')
        .eq('empresa_id', empresaId)
        .eq('tipo_registro', 'compras')

      if (existentesError) {
        throw new Error(`No se pudieron validar duplicados: ${existentesError.message}`)
      }

      const existentes = new Set(
        ((existentesData ?? []) as {
          tipo_doc_codigo: number
          rut_tercero: string | null
          folio: string
        }[]).map(
          (doc) =>
            `${doc.tipo_doc_codigo}|${doc.rut_tercero || ''}|${doc.folio || ''}`
        )
      )

      const documentosNuevos = documentosCsv.filter((doc) => {
        const key = `${doc.tipo_doc_codigo}|${doc.rut_tercero || ''}|${doc.folio || ''}`
        return !existentes.has(key)
      })

      const periodo = getPeriodoFromFileName(file.name)

      const { data: importacion, error: importacionError } = await supabase
        .from('sii_importaciones')
        .insert({
          empresa_id: empresaId,
          tipo_registro: 'compras',
          periodo,
          nombre_archivo: file.name,
          total_filas: documentosCsv.length,
          estado: 'procesada',
          created_by: userId,
          updated_by: userId,
        })
        .select('id')
        .single()

      if (importacionError) {
        throw new Error(`No se pudo registrar la importación: ${importacionError.message}`)
      }

      if (documentosNuevos.length > 0) {
        const payload = documentosNuevos.map((doc) => ({
          empresa_id: empresaId,
          importacion_id: importacion.id,
          tipo_registro: 'compras',
          tipo_doc_codigo: doc.tipo_doc_codigo,
          tipo_doc_nombre: doc.tipo_doc_nombre,
          tipo_compra_venta: doc.tipo_compra_venta,
          rut_tercero: doc.rut_tercero,
          razon_social: doc.razon_social,
          folio: doc.folio,
          fecha_docto: doc.fecha_docto,
          fecha_recepcion: doc.fecha_recepcion,
          fecha_acuse: doc.fecha_acuse,
          monto_exento: doc.monto_exento,
          monto_neto: doc.monto_neto,
          monto_iva_recuperable: doc.monto_iva_recuperable,
          monto_iva_no_recuperable: doc.monto_iva_no_recuperable,
          monto_iva: doc.monto_iva,
          monto_total: doc.monto_total,
          monto_neto_activo_fijo: doc.monto_neto_activo_fijo,
          iva_activo_fijo: doc.iva_activo_fijo,
          iva_uso_comun: doc.iva_uso_comun,
          impuesto_sin_derecho_credito: doc.impuesto_sin_derecho_credito,
          codigo_otro_impuesto: doc.codigo_otro_impuesto,
          valor_otro_impuesto: doc.valor_otro_impuesto,
          tasa_otro_impuesto: doc.tasa_otro_impuesto,
          accion_sugerida: doc.accion_sugerida,
          estado: doc.accion_sugerida === 'solo_documental'
            ? 'solo_documental'
            : 'pendiente',
          raw_data: doc.raw_data,
          created_by: userId,
          updated_by: userId,
        }))

        const { error: insertError } = await supabase
          .from('sii_documentos')
          .insert(payload)

        if (insertError) {
          throw new Error(`No se pudieron guardar documentos: ${insertError.message}`)
        }
      }

      setSuccess(
        `Importación completada. Documentos leídos: ${documentosCsv.length}. Nuevos: ${documentosNuevos.length}. Duplicados omitidos: ${documentosCsv.length - documentosNuevos.length}.`
      )

      await loadDocumentos()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo importar el CSV del SII.')
    } finally {
      setImporting(false)
    }
  }
  const autoVincularConIngresosExistentes = async (showLoading = false) => {
    try {
      if (!empresaId) return 0

      if (showLoading) {
        setLinkingExistingIngresos(true)
      }

      const { data: documentosData, error: documentosError } = await supabase
        .from('sii_documentos')
        .select('id, tipo_doc_codigo, rut_tercero, folio, monto_total, estado, movimiento_id')
        .eq('empresa_id', empresaId)
        .eq('tipo_registro', 'ventas')
        .in('estado', ['pendiente', 'solo_documental'])
        .is('movimiento_id', null)

      if (documentosError) {
        throw new Error(`No se pudieron cargar documentos SII de ventas: ${documentosError.message}`)
      }

      const documentosPendientes = ((documentosData ?? []) as {
        id: string
        tipo_doc_codigo: number
        rut_tercero: string | null
        folio: string
        monto_total: number | string | null
        estado: string
        movimiento_id: string | null
      }[]).filter((doc) => [33, 34, 39, 41, 56, 61].includes(Number(doc.tipo_doc_codigo)))

      if (documentosPendientes.length === 0) return 0

      const { data: clientesData, error: clientesError } = await supabase
        .from('clientes')
        .select('id, rut')
        .eq('empresa_id', empresaId)
        .eq('activo', true)
        .is('deleted_at', null)

      if (clientesError) {
        throw new Error(`No se pudieron cargar clientes: ${clientesError.message}`)
      }

      const clientePorRut = new Map<string, string>()

      for (const cliente of (clientesData ?? []) as { id: string; rut: string | null }[]) {
        const rutNormalizado = normalizeRutSii(cliente.rut)
        if (rutNormalizado) clientePorRut.set(rutNormalizado, cliente.id)
      }

      const documentosConCliente = documentosPendientes
        .map((doc) => ({
          ...doc,
          cliente_id: clientePorRut.get(normalizeRutSii(doc.rut_tercero)) || null,
        }))
        .filter((doc) => doc.cliente_id)

      if (documentosConCliente.length === 0) return 0

      const clienteIds = Array.from(
        new Set(documentosConCliente.map((doc) => doc.cliente_id as string))
      )

      const folios = Array.from(
        new Set(
          documentosConCliente
            .map((doc) => String(doc.folio || '').trim())
            .filter(Boolean)
        )
      )

      const { data: movimientosData, error: movimientosError } = await supabase
        .from('movimientos')
        .select('id, cliente_id, numero_documento, monto_total, tipo_documento')
        .eq('empresa_id', empresaId)
        .eq('tipo_movimiento', 'ingreso')
        .eq('activo', true)
        .is('deleted_at', null)
        .in('cliente_id', clienteIds)
        .in('numero_documento', folios)

      if (movimientosError) {
        throw new Error(`No se pudieron cargar ingresos existentes: ${movimientosError.message}`)
      }

      const movimientos = (movimientosData ?? []) as {
        id: string
        cliente_id: string | null
        numero_documento: string | null
        monto_total: number | string | null
        tipo_documento: string | null
      }[]

      let vinculados = 0

      for (const doc of documentosConCliente) {
        const candidatos = movimientos.filter(
          (mov) =>
            mov.cliente_id === doc.cliente_id &&
            String(mov.numero_documento || '').trim() === String(doc.folio || '').trim()
        )

        const matchPorMonto =
          candidatos.find((mov) => amountsAreClose(mov.monto_total, doc.monto_total)) || null

        const match = matchPorMonto || (candidatos.length === 1 ? candidatos[0] : null)

        if (!match) continue

        const { error: updateError } = await supabase
          .from('sii_documentos')
          .update({
            estado: 'vinculado',
            accion_sugerida: 'revisar',
            movimiento_id: match.id,
            cliente_id: doc.cliente_id,
            updated_at: new Date().toISOString(),
          })
          .eq('id', doc.id)
          .eq('empresa_id', empresaId)

        if (updateError) {
          throw new Error(`No se pudo vincular venta SII ${doc.folio}: ${updateError.message}`)
        }

        vinculados += 1
      }

      return vinculados
    } finally {
      if (showLoading) setLinkingExistingIngresos(false)
    }
  }

  const handleVincularIngresosExistentes = async () => {
    try {
      setError('')
      setSuccess('')

      const vinculados = await autoVincularConIngresosExistentes(true)

      setSuccess(
        vinculados > 0
          ? `Se vincularon ${vinculados} documento${vinculados === 1 ? '' : 's'} SII con ingresos existentes.`
          : 'No se encontraron documentos SII de ventas que coincidan con ingresos existentes.'
      )

      await loadDocumentos()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudieron vincular ingresos existentes.')
    }
  }

  const handleImportCsvVentas = async (file: File | null) => {
    if (!file) return

    try {
      if (!empresaId) {
        throw new Error('No hay empresa activa seleccionada.')
      }

      setImporting(true)
      setError('')
      setSuccess('')

      const text = await file.text()
      const documentosCsv = parseSiiVentasCsv(text)

      if (documentosCsv.length === 0) {
        throw new Error('No se encontraron documentos de ventas válidos en el CSV.')
      }

      const { data: userData } = await supabase.auth.getUser()
      const userId = userData.user?.id || null

      const { data: existentesData, error: existentesError } = await supabase
        .from('sii_documentos')
        .select('tipo_doc_codigo, rut_tercero, folio')
        .eq('empresa_id', empresaId)
        .eq('tipo_registro', 'ventas')

      if (existentesError) {
        throw new Error(`No se pudieron validar duplicados: ${existentesError.message}`)
      }

      const existentes = new Set(
        ((existentesData ?? []) as {
          tipo_doc_codigo: number
          rut_tercero: string | null
          folio: string
        }[]).map(
          (doc) =>
            `${doc.tipo_doc_codigo}|${doc.rut_tercero || ''}|${doc.folio || ''}`
        )
      )

      const documentosNuevos = documentosCsv.filter((doc) => {
        const key = `${doc.tipo_doc_codigo}|${doc.rut_tercero || ''}|${doc.folio || ''}`
        return !existentes.has(key)
      })

      const periodo = getPeriodoFromFileName(file.name)

      const { data: importacion, error: importacionError } = await supabase
        .from('sii_importaciones')
        .insert({
          empresa_id: empresaId,
          tipo_registro: 'ventas',
          periodo,
          nombre_archivo: file.name,
          total_filas: documentosCsv.length,
          estado: 'procesada',
          created_by: userId,
          updated_by: userId,
        })
        .select('id')
        .single()

      if (importacionError) {
        throw new Error(`No se pudo registrar la importación de ventas: ${importacionError.message}`)
      }

      if (documentosNuevos.length > 0) {
        const payload = documentosNuevos.map((doc) => ({
          empresa_id: empresaId,
          importacion_id: importacion.id,
          tipo_registro: 'ventas',
          tipo_doc_codigo: doc.tipo_doc_codigo,
          tipo_doc_nombre: doc.tipo_doc_nombre,
          tipo_compra_venta: doc.tipo_compra_venta,
          rut_tercero: doc.rut_tercero,
          razon_social: doc.razon_social,
          folio: doc.folio,
          fecha_docto: doc.fecha_docto,
          fecha_recepcion: doc.fecha_recepcion,
          fecha_acuse: doc.fecha_acuse,
          monto_exento: doc.monto_exento,
          monto_neto: doc.monto_neto,
          monto_iva_recuperable: doc.monto_iva_recuperable,
          monto_iva_no_recuperable: doc.monto_iva_no_recuperable,
          monto_iva: doc.monto_iva,
          monto_total: doc.monto_total,
          monto_neto_activo_fijo: doc.monto_neto_activo_fijo,
          iva_activo_fijo: doc.iva_activo_fijo,
          iva_uso_comun: doc.iva_uso_comun,
          impuesto_sin_derecho_credito: doc.impuesto_sin_derecho_credito,
          codigo_otro_impuesto: doc.codigo_otro_impuesto,
          valor_otro_impuesto: doc.valor_otro_impuesto,
          tasa_otro_impuesto: doc.tasa_otro_impuesto,
          accion_sugerida: doc.accion_sugerida,
          estado: doc.accion_sugerida === 'solo_documental'
            ? 'solo_documental'
            : 'pendiente',
          raw_data: doc.raw_data,
          created_by: userId,
          updated_by: userId,
        }))

        const { error: insertError } = await supabase
          .from('sii_documentos')
          .insert(payload)

        if (insertError) {
          throw new Error(`No se pudieron guardar documentos de ventas: ${insertError.message}`)
        }
      }

      setSuccess(
        `Importación de ventas completada. Documentos leídos: ${documentosCsv.length}. Nuevos: ${documentosNuevos.length}. Duplicados omitidos: ${documentosCsv.length - documentosNuevos.length}.`
      )

      await loadDocumentos()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo importar el CSV de ventas del SII.')
    } finally {
      setImporting(false)
    }
  }
  const openReviewModal = (documento: SiiDocumento) => {
    const rutDocumento = normalizeRutSii(documento.rut_tercero)
    const terceros = documento.tipo_registro === 'ventas' ? clientes : proveedores
    const terceroDetectado = terceros.find(
      (tercero) => normalizeRutSii(tercero.rut) === rutDocumento
    )
    const terceroId =
      documento.tipo_registro === 'ventas'
        ? documento.cliente_id || terceroDetectado?.id || ''
        : documento.proveedor_id || terceroDetectado?.id || ''
    const terceroInicial = terceros.find((tercero) => tercero.id === terceroId)

    setSelectedDocumento(documento)
    setReviewForm({
      ...EMPTY_REVIEW_FORM,
      descripcion: getDescripcionSugerida(documento),
      tercero_id: terceroId,
      fecha_vencimiento: calcularFechaVencimientoSugerida(documento, terceroInicial),
    })
    setShowReviewModal(true)
    setError('')
    setSuccess('')
  }

  const closeReviewModal = () => {
    setSelectedDocumento(null)
    setReviewForm(EMPTY_REVIEW_FORM)
    setShowReviewModal(false)
  }

  const handleImportXmlDte = async (file: File | null) => {
    if (!file) return

    try {
      if (!empresaId) {
        throw new Error('No hay empresa activa seleccionada.')
      }

      setImportingXml(true)
      setError('')
      setSuccess('')

      const text = await file.text()
      const documentosXml = parseDteXml(text)

      if (documentosXml.length === 0) {
        throw new Error('No se encontraron DTE válidos dentro del XML.')
      }

      const { data: siiDocsData, error: siiDocsError } = await supabase
        .from('sii_documentos')
        .select('id, tipo_registro, tipo_doc_codigo, folio, rut_tercero, monto_total, xml_importado')
        .eq('empresa_id', empresaId)

      if (siiDocsError) {
        throw new Error(`No se pudieron cargar documentos SII: ${siiDocsError.message}`)
      }

      const siiDocs = (siiDocsData ?? []) as {
        id: string
        tipo_registro: 'compras' | 'ventas'
        tipo_doc_codigo: number
        folio: string
        rut_tercero: string | null
        monto_total: number | string | null
        xml_importado: boolean | null
      }[]

      let actualizados = 0
      let noEncontrados = 0

      for (const xmlDoc of documentosXml) {
        const rutEmisor = normalizeRutSii(xmlDoc.rut_emisor)
        const rutReceptor = normalizeRutSii(xmlDoc.rut_receptor)

        const candidatos = siiDocs.filter((doc) => {
          if (Number(doc.tipo_doc_codigo) !== Number(xmlDoc.tipo_doc_codigo)) return false
          if (String(doc.folio || '').trim() !== String(xmlDoc.folio || '').trim()) return false

          const rutTercero = normalizeRutSii(doc.rut_tercero)

          if (doc.tipo_registro === 'ventas' && rutTercero === rutReceptor) return true
          if (doc.tipo_registro === 'compras' && rutTercero === rutEmisor) return true

          return false
        })

        const matchPorMonto =
          candidatos.find((doc) => amountsAreClose(doc.monto_total, xmlDoc.monto_total)) ||
          null

        const match = matchPorMonto || (candidatos.length === 1 ? candidatos[0] : null)

        if (!match) {
          noEncontrados += 1
          continue
        }

        const { error: updateError } = await supabase
          .from('sii_documentos')
          .update({
            xml_importado: true,
            xml_nombre_archivo: file.name,
            xml_importado_at: new Date().toISOString(),
            descripcion_xml:
              xmlDoc.descripcion_xml ||
              `${getSiiTipoDocNombre(xmlDoc.tipo_doc_codigo)} SII N° ${xmlDoc.folio}`,
            detalle_items_xml: xmlDoc.detalle_items_xml,
            updated_at: new Date().toISOString(),
          })
          .eq('id', match.id)
          .eq('empresa_id', empresaId)

        if (updateError) {
          throw new Error(`No se pudo actualizar DTE folio ${xmlDoc.folio}: ${updateError.message}`)
        }

        actualizados += 1
      }

      setSuccess(
        `XML procesado. DTE leídos: ${documentosXml.length}. Documentos actualizados: ${actualizados}. Sin coincidencia: ${noEncontrados}.`
      )

      await loadDocumentos()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo importar el XML DTE.')
    } finally {
      setImportingXml(false)
    }
  }

  const handleMarcarDocumental = async () => {
    if (!selectedDocumento) return

    try {
      setCreatingMovimiento(true)
      setError('')
      setSuccess('')

      const { data: userData } = await supabase.auth.getUser()
      const userId = userData.user?.id || null

      const { error: updateError } = await supabase
        .from('sii_documentos')
        .update({
          estado: 'solo_documental',
          accion_sugerida: 'solo_documental',
          observaciones: reviewForm.descripcion || selectedDocumento.observaciones,
          updated_by: userId,
          updated_at: new Date().toISOString(),
        })
        .eq('id', selectedDocumento.id)
        .eq('empresa_id', empresaId)

      if (updateError) {
        throw new Error(updateError.message)
      }

      setSuccess('Documento marcado como solo documental.')
      closeReviewModal()
      await loadDocumentos()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo marcar como documental.')
    } finally {
      setCreatingMovimiento(false)
    }
  }

  const handleCrearMovimientoDesdeSii = async () => {
    if (!selectedDocumento) return

    try {
      setCreatingMovimiento(true)
      setError('')
      setSuccess('')

      if (selectedDocumento.movimiento_id || selectedDocumento.estado === 'convertido') {
        throw new Error('Este documento ya tiene un movimiento asociado.')
      }

      if (selectedDocumento.accion_sugerida === 'solo_documental') {
        throw new Error('Este documento está definido como solo documental.')
      }

      if (!reviewForm.tercero_id) {
        throw new Error(
          selectedDocumento.tipo_registro === 'ventas'
            ? 'Debes seleccionar el cliente.'
            : 'Debes seleccionar el proveedor.'
        )
      }

      if (!reviewForm.categoria_id) {
        throw new Error('Debes seleccionar una categoría.')
      }

      if (reviewForm.estado_pago === 'pagado' && !reviewForm.cuenta_bancaria_id) {
        throw new Error('Debes seleccionar una cuenta bancaria si el movimiento está pagado.')
      }

      if (!reviewForm.descripcion.trim()) {
        throw new Error('Debes indicar una descripción para el movimiento.')
      }

      const { data: userData } = await supabase.auth.getUser()
      const userId = userData.user?.id || null

      const tipoMovimiento = getMovimientoTipoFromDoc(selectedDocumento)
      const fechaDocumento = selectedDocumento.fecha_docto || todayLocalDate()
      const montoTotal = getSignedAmountForDoc(selectedDocumento, selectedDocumento.monto_total)

      let movimientoExistenteQuery = supabase
        .from('movimientos')
        .select('id, monto_total')
        .eq('empresa_id', empresaId)
        .eq('tipo_movimiento', tipoMovimiento)
        .eq('numero_documento', selectedDocumento.folio)
        .eq('activo', true)
        .is('deleted_at', null)

      if (selectedDocumento.tipo_registro === 'ventas') {
        movimientoExistenteQuery = movimientoExistenteQuery.eq('cliente_id', reviewForm.tercero_id)
      } else {
        movimientoExistenteQuery = movimientoExistenteQuery.eq('proveedor_id', reviewForm.tercero_id)
      }

      const { data: movimientosExistentes, error: movimientosExistentesError } =
        await movimientoExistenteQuery

      if (movimientosExistentesError) {
        throw new Error(
          `No se pudo validar si el movimiento ya existe: ${movimientosExistentesError.message}`
        )
      }

      const movimientoExistente = ((movimientosExistentes ?? []) as {
        id: string
        monto_total: number | string | null
        xml_importado: boolean | null
      }[]).find((mov) => amountsAreClose(mov.monto_total, montoTotal))

      if (movimientoExistente) {
        const { error: vincularError } = await supabase
          .from('sii_documentos')
          .update({
            estado: 'vinculado',
            accion_sugerida: 'revisar',
            movimiento_id: movimientoExistente.id,
            proveedor_id:
              selectedDocumento.tipo_registro === 'compras' ? reviewForm.tercero_id : null,
            cliente_id:
              selectedDocumento.tipo_registro === 'ventas' ? reviewForm.tercero_id : null,
            categoria_id: reviewForm.categoria_id,
            centro_costo_id: reviewForm.centro_costo_id || null,
            observaciones: reviewForm.descripcion.trim(),
            updated_by: userId,
            updated_at: new Date().toISOString(),
          })
          .eq('id', selectedDocumento.id)
          .eq('empresa_id', empresaId)

        if (vincularError) {
          throw new Error(
            `Ya existe el movimiento, pero no se pudo vincular el documento SII: ${vincularError.message}`
          )
        }

        setSuccess(
          selectedDocumento.tipo_registro === 'ventas'
            ? 'Ya existía un ingreso con este folio, cliente y monto. El documento SII fue vinculado.'
            : 'Ya existía un egreso con este folio, proveedor y monto. El documento SII fue vinculado.'
        )

        closeReviewModal()
        await loadDocumentos()
        return
      }

      const movimientoPayload = {
        empresa_id: empresaId,
        tipo_movimiento: tipoMovimiento,
        fecha: fechaDocumento,
        fecha_vencimiento: reviewForm.fecha_vencimiento || fechaDocumento,
        tercero_tipo: selectedDocumento.tipo_registro === 'ventas' ? 'cliente' : 'proveedor',
        cliente_id:
          selectedDocumento.tipo_registro === 'ventas' ? reviewForm.tercero_id : null,
        proveedor_id:
          selectedDocumento.tipo_registro === 'compras' ? reviewForm.tercero_id : null,
        categoria_id: reviewForm.categoria_id,
        centro_costo_id: reviewForm.centro_costo_id || null,
        cuenta_contable_id: null,
        cuenta_bancaria_id:
          reviewForm.estado_pago === 'pagado' ? reviewForm.cuenta_bancaria_id : null,
        tipo_documento: getMovimientoTipoDocumento(selectedDocumento.tipo_doc_codigo),
        numero_documento: selectedDocumento.folio,
        descripcion: reviewForm.descripcion.trim(),
        monto_neto: getSignedAmountForDoc(selectedDocumento, selectedDocumento.monto_neto),
        monto_iva: getSignedAmountForDoc(selectedDocumento, selectedDocumento.monto_iva),
        monto_exento: getSignedAmountForDoc(selectedDocumento, selectedDocumento.monto_exento),
        monto_total: montoTotal,
        estado: reviewForm.estado_pago,
        medio_pago: reviewForm.estado_pago === 'pagado' ? 'transferencia' : null,
        observaciones: `Creado desde documento SII ${selectedDocumento.id}`,
        impuesto_especifico: 0,
        tratamiento_tributario: getTratamientoTributarioFromDoc(selectedDocumento),
        activo: true,
        created_by: userId,
        updated_by: userId,
        updated_at: new Date().toISOString(),
      }

      const { data: movimiento, error: movimientoError } = await supabase
        .from('movimientos')
        .insert(movimientoPayload)
        .select('id')
        .single()

      if (movimientoError) {
        throw new Error(`No se pudo crear el movimiento: ${movimientoError.message}`)
      }

      if (
        selectedDocumento.tipo_registro === 'ventas' &&
        reviewForm.estado_pago === 'pendiente' &&
        selectedDocumento.accion_sugerida !== 'ajuste_negativo' &&
        montoTotal > 0
      ) {
        const { error: cxcError } = await supabase.from('cuentas_por_cobrar').insert({
          empresa_id: empresaId,
          movimiento_id: movimiento.id,
          cliente_id: reviewForm.tercero_id,
          fecha_emision: fechaDocumento,
          fecha_vencimiento: reviewForm.fecha_vencimiento || null,
          monto_total: montoTotal,
          monto_pagado: 0,
          saldo_pendiente: montoTotal,
          estado: 'pendiente',
          activo: true,
          created_by: userId,
          updated_by: userId,
        })

        if (cxcError) {
          throw new Error(
            `El ingreso fue creado, pero no se pudo crear la cuenta por cobrar: ${cxcError.message}`
          )
        }
      }


      if (
        selectedDocumento.tipo_registro === 'compras' &&
        reviewForm.estado_pago === 'pendiente' &&
        selectedDocumento.accion_sugerida !== 'ajuste_negativo' &&
        montoTotal > 0
      ) {
        const { error: cxpError } = await supabase.from('cuentas_por_pagar').insert({
          empresa_id: empresaId,
          movimiento_id: movimiento.id,
          proveedor_id: reviewForm.tercero_id,
          fecha_emision: fechaDocumento,
          fecha_vencimiento: reviewForm.fecha_vencimiento || fechaDocumento,
          monto_total: montoTotal,
          monto_pagado: 0,
          saldo_pendiente: montoTotal,
          estado: 'pendiente',
          activo: true,
          created_by: userId,
          updated_by: userId,
        })

        if (cxpError) {
          throw new Error(
            `El egreso fue creado, pero no se pudo crear la cuenta por pagar: ${cxpError.message}`
          )
        }
      }
      const { error: updateDocError } = await supabase
        .from('sii_documentos')
        .update({
          estado: 'convertido',
          movimiento_id: movimiento.id,
          proveedor_id:
            selectedDocumento.tipo_registro === 'compras' ? reviewForm.tercero_id : null,
          cliente_id:
            selectedDocumento.tipo_registro === 'ventas' ? reviewForm.tercero_id : null,
          categoria_id: reviewForm.categoria_id,
          centro_costo_id: reviewForm.centro_costo_id || null,
          observaciones: reviewForm.descripcion.trim(),
          updated_by: userId,
          updated_at: new Date().toISOString(),
        })
        .eq('id', selectedDocumento.id)
        .eq('empresa_id', empresaId)

      if (updateDocError) {
        throw new Error(
          `El movimiento fue creado, pero no se pudo actualizar el documento SII: ${updateDocError.message}`
        )
      }

      setSuccess(
        selectedDocumento.tipo_registro === 'ventas'
          ? 'Ingreso creado correctamente desde Documento SII.'
          : 'Egreso creado correctamente desde Documento SII.'
      )

      closeReviewModal()
      await loadDocumentos()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo crear el movimiento.')
    } finally {
      setCreatingMovimiento(false)
    }
  }
  const limpiarFiltros = () => {
    setQ('')
    setTipoRegistro('')
    setEstado('')
    setTipoDoc('')
  }

  if (!empresaId && !loading) {
    return (
      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6 text-amber-800">
        No hay empresa activa seleccionada.
      </div>
    )
  }

  return (
    <main className="space-y-6">
      <header className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">Módulo</p>
            <h1 className="mt-1 text-3xl font-semibold tracking-tight text-slate-900">
              Documentos SII
            </h1>
            <p className="mt-2 max-w-3xl text-sm text-slate-600">
              Registro documental de compras, ventas, notas de crédito, notas de débito y guías de despacho importadas desde el SII.
            </p>
            <p className="mt-2 text-sm text-slate-500">
              Empresa activa:{' '}
              <span className="font-medium text-slate-900">
                {empresaNombre || empresaId}
              </span>
            </p>
          </div>

          <button
            type="button"
            onClick={() => void loadDocumentos()}
            className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            Actualizar
          </button>
        </div>
      </header>



      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Vinculación automática
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Compara documentos SII pendientes con egresos ya ingresados manualmente y los marca como vinculados cuando coinciden proveedor, folio y monto.
            </p>
          </div>

          <button
            type="button"
            onClick={() => void handleVincularEgresosExistentes()}
            disabled={linkingExistingDocs}
            className="rounded-xl border border-[#163A5F] bg-white px-4 py-2 text-sm font-semibold text-[#163A5F] hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-70"
          >
            {linkingExistingDocs ? 'Vinculando...' : 'Vincular egresos existentes'}
          </button>
        </div>
      </section>
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Importar CSV de compras SII
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Sube el Registro de Compra del SII. Se registrarán facturas, notas de crédito, notas de débito y guías como documentos SII.
            </p>
          </div>

          <label className="inline-flex cursor-pointer items-center justify-center rounded-xl border border-[#163A5F] bg-white px-4 py-2 text-sm font-semibold text-[#163A5F] hover:bg-blue-50">
            {importing ? 'Importando...' : 'Seleccionar CSV'}
            <input
              type="file"
              accept=".csv,text/csv"
              disabled={importing}
              className="hidden"
              onChange={(event) => {
                const file = event.target.files?.[0] || null
                void handleImportCsv(file)
                event.target.value = ''
              }}
            />
          </label>
        </div>
      </section>
      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      {success ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">
          {success}
        </div>
      ) : null}

      

      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Vinculación de ventas
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Compara documentos SII de ventas con ingresos ya ingresados manualmente y los marca como vinculados cuando coinciden cliente, folio y monto.
            </p>
          </div>

          <button
            type="button"
            onClick={() => void handleVincularIngresosExistentes()}
            disabled={linkingExistingIngresos}
            className="rounded-xl border border-[#163A5F] bg-white px-4 py-2 text-sm font-semibold text-[#163A5F] hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-70"
          >
            {linkingExistingIngresos ? 'Vinculando...' : 'Vincular ingresos existentes'}
          </button>
        </div>
      </section>
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Importar CSV de ventas SII
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Sube el Registro de Ventas del SII. Se registrarán facturas de venta, notas de crédito, notas de débito y documentos tributarios emitidos.
            </p>
          </div>

          <label className="inline-flex cursor-pointer items-center justify-center rounded-xl border border-[#163A5F] bg-white px-4 py-2 text-sm font-semibold text-[#163A5F] hover:bg-blue-50">
            {importing ? 'Importando...' : 'Seleccionar CSV ventas'}
            <input
              type="file"
              accept=".csv,text/csv"
              disabled={importing}
              className="hidden"
              onChange={(event) => {
                const file = event.target.files?.[0] || null
                void handleImportCsvVentas(file)
                event.target.value = ''
              }}
            />
          </label>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Importar XML DTE
            </h2>
            <p className="mt-1 text-sm text-slate-500">
              Sube el XML descargado del SII para completar la descripción real e ítems de cada documento ya importado desde CSV.
            </p>
          </div>

          <label className="inline-flex cursor-pointer items-center justify-center rounded-xl border border-[#163A5F] bg-white px-4 py-2 text-sm font-semibold text-[#163A5F] hover:bg-blue-50">
            {importingXml ? 'Importando XML...' : 'Seleccionar XML'}
            <input
              type="file"
              accept=".xml,text/xml,application/xml"
              disabled={importingXml}
              className="hidden"
              onChange={(event) => {
                const file = event.target.files?.[0] || null
                void handleImportXmlDte(file)
                event.target.value = ''
              }}
            />
          </label>
        </div>
      </section>
      <section className="grid gap-4 md:grid-cols-3 xl:grid-cols-6">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="text-sm text-slate-500">Documentos</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900">
            {resumen.total}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="text-sm text-slate-500">Compras</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900">
            {resumen.compras}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="text-sm text-slate-500">Ventas</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900">
            {resumen.ventas}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="text-sm text-slate-500">Pendientes</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900">
            {resumen.pendientes}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="text-sm text-slate-500">Notas crédito</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900">
            {resumen.notasCredito}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="text-sm text-slate-500">Monto total</p>
          <p className="mt-2 text-lg font-semibold text-slate-900">
            {formatCurrency(resumen.montoTotal)}
          </p>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="grid gap-4 xl:grid-cols-[1fr_180px_180px_220px_140px]">
          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700">
              Buscar
            </label>
            <input
              value={q}
              onChange={(event) => setQ(event.target.value)}
              placeholder="RUT, razón social, folio o tipo documento"
              className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700">
              Registro
            </label>
            <select
              value={tipoRegistro}
              onChange={(event) => setTipoRegistro(event.target.value)}
              className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
            >
              <option value="">Todos</option>
              <option value="compras">Compras</option>
              <option value="ventas">Ventas</option>
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700">
              Estado
            </label>
            <select
              value={estado}
              onChange={(event) => setEstado(event.target.value)}
              className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
            >
              <option value="">Todos</option>
              <option value="pendiente">Pendiente</option>
              <option value="convertido">Convertido</option>
              <option value="solo_documental">Solo documental</option>
              <option value="omitido">Omitido</option>
              <option value="vinculado">Vinculado</option>
              <option value="anulado">Anulado</option>
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700">
              Tipo documento
            </label>
            <select
              value={tipoDoc}
              onChange={(event) => setTipoDoc(event.target.value)}
              className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
            >
              <option value="">Todos</option>
              {tiposDisponibles.map((codigo) => (
                <option key={codigo} value={String(codigo)}>
                  {codigo} - {TIPO_DOC_LABELS[codigo] || 'Documento SII'}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-end">
            <button
              type="button"
              onClick={limpiarFiltros}
              className="w-full rounded-xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Limpiar
            </button>
          </div>
        </div>
      </section>

      <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-200 px-5 py-4">
          <h2 className="text-base font-semibold text-slate-900">
            Listado de documentos
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            {filtered.length} resultado{filtered.length === 1 ? '' : 's'}
          </p>
        </div>

        {loading ? (
          <div className="p-6 text-sm text-slate-600">
            Cargando documentos SII...
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-600">
            No hay documentos SII para mostrar.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-50 text-left text-slate-600">
                <tr>
                  <th className="px-4 py-3 font-semibold">Registro</th>
                  <th className="px-4 py-3 font-semibold">Tipo doc</th>
                  <th className="px-4 py-3 font-semibold">Folio</th>
                  <th className="px-4 py-3 font-semibold">Fecha</th>
                  <th className="px-4 py-3 font-semibold">RUT</th>
                  <th className="px-4 py-3 font-semibold">Razón social</th>
                  <th className="px-4 py-3 text-right font-semibold">Exento</th>
                  <th className="px-4 py-3 text-right font-semibold">Neto</th>
                  <th className="px-4 py-3 text-right font-semibold">IVA</th>
                  <th className="px-4 py-3 text-right font-semibold">Total</th>
                  <th className="px-4 py-3 font-semibold">Acción</th>
                  <th className="px-4 py-3 font-semibold">Estado</th>
                  <th className="px-4 py-3 text-right font-semibold">Acciones</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-200">
                {filtered.map((doc) => (
                  <tr key={doc.id} className="align-top hover:bg-slate-50/70">
                    <td className="px-4 py-3 capitalize text-slate-700">
                      {doc.tipo_registro}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-900">
                        {doc.tipo_doc_codigo}
                      </div>
                      <div className="text-xs text-slate-500">
                        {getTipoDocNombre(doc.tipo_doc_codigo, doc.tipo_doc_nombre)}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900">
                      {doc.folio}
                    </td>
                    <td className="px-4 py-3 text-slate-700">
                      {formatDate(doc.fecha_docto)}
                    </td>
                    <td className="px-4 py-3 text-slate-700">
                      {doc.rut_tercero || '-'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="max-w-[260px] whitespace-normal break-words text-slate-700">
                        {doc.razon_social || '-'}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right text-slate-700">
                      {formatCurrency(doc.monto_exento)}
                    </td>
                    <td className="px-4 py-3 text-right text-slate-700">
                      {formatCurrency(doc.monto_neto)}
                    </td>
                    <td className="px-4 py-3 text-right text-slate-700">
                      {formatCurrency(doc.monto_iva)}
                    </td>
                    <td className="px-4 py-3 text-right font-medium text-slate-900">
                      {formatCurrency(doc.monto_total)}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
                          getAccionVisualClass(doc)
                        }`}
                      >
                        {getAccionVisualLabel(doc)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
                          getEstadoClass(doc.estado)
                        }`}
                      >
                        {ESTADO_LABELS[doc.estado] || doc.estado}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => openReviewModal(doc)}
                        className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100"
                      >
                        Revisar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {showReviewModal && selectedDocumento ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="max-h-[90vh] w-full max-w-5xl overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-4 md:flex-row md:items-start md:justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">
                  Revisión previa
                </p>
                <h3 className="mt-1 text-2xl font-semibold text-slate-900">
                  Revisar documento SII
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Revisa los datos antes de crear el ingreso, egreso o ajuste correspondiente.
                </p>
              </div>

              <button
                type="button"
                onClick={closeReviewModal}
                className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100"
              >
                Cerrar
              </button>
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-3">
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Registro
                </p>
                <p className="mt-1 text-sm font-medium capitalize text-slate-900">
                  {selectedDocumento.tipo_registro}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Tipo documento
                </p>
                <p className="mt-1 text-sm font-medium text-slate-900">
                  {selectedDocumento.tipo_doc_codigo} - {getTipoDocNombre(
                    selectedDocumento.tipo_doc_codigo,
                    selectedDocumento.tipo_doc_nombre
                  )}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Folio
                </p>
                <p className="mt-1 text-sm font-medium text-slate-900">
                  {selectedDocumento.folio}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Fecha documento
                </p>
                <p className="mt-1 text-sm font-medium text-slate-900">
                  {formatDate(selectedDocumento.fecha_docto)}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  RUT tercero
                </p>
                <p className="mt-1 text-sm font-medium text-slate-900">
                  {selectedDocumento.rut_tercero || '-'}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Razón social
                </p>
                <p className="mt-1 text-sm font-medium text-slate-900">
                  {selectedDocumento.razon_social || '-'}
                </p>
              </div>
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-4">
              <div className="rounded-xl border border-slate-200 bg-white p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Exento
                </p>
                <p className="mt-1 text-lg font-semibold text-slate-900">
                  {formatCurrency(selectedDocumento.monto_exento)}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Neto
                </p>
                <p className="mt-1 text-lg font-semibold text-slate-900">
                  {formatCurrency(selectedDocumento.monto_neto)}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  IVA
                </p>
                <p className="mt-1 text-lg font-semibold text-slate-900">
                  {formatCurrency(selectedDocumento.monto_iva)}
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Total
                </p>
                <p className="mt-1 text-lg font-semibold text-slate-900">
                  {formatCurrency(selectedDocumento.monto_total)}
                </p>
              </div>
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-3">
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Acción sugerida
                </p>
                <span
                  className={`mt-2 inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
                    getAccionVisualClass(selectedDocumento)
                  }`}
                >
                  {getAccionVisualLabel(selectedDocumento)}
                </span>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Estado
                </p>
                <span
                  className={`mt-2 inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
                    getEstadoClass(selectedDocumento.estado)
                  }`}
                >
                  {ESTADO_LABELS[selectedDocumento.estado] || selectedDocumento.estado}
                </span>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Movimiento vinculado
                </p>
                <p className="mt-1 text-sm font-medium text-slate-900">
                  {selectedDocumento.movimiento_id ? 'Sí' : 'No'}
                </p>
              </div>
            </div>



            {selectedDocumento.xml_importado ? (
              <div className="mt-6 rounded-2xl border border-blue-200 bg-blue-50 p-5">
                <h4 className="text-base font-semibold text-blue-950">
                  Detalle obtenido desde XML
                </h4>
                <p className="mt-1 text-sm text-blue-800">
                  Archivo: {selectedDocumento.xml_nombre_archivo || '-'}
                </p>

                {selectedDocumento.descripcion_xml ? (
                  <div className="mt-4 rounded-xl border border-blue-100 bg-white p-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Descripción sugerida
                    </p>
                    <p className="mt-1 text-sm text-slate-800">
                      {selectedDocumento.descripcion_xml}
                    </p>
                  </div>
                ) : null}

                {Array.isArray(selectedDocumento.detalle_items_xml) &&
                selectedDocumento.detalle_items_xml.length > 0 ? (
                  <div className="mt-4 overflow-hidden rounded-xl border border-blue-100 bg-white">
                    <table className="min-w-full text-sm">
                      <thead className="bg-slate-50 text-left text-slate-600">
                        <tr>
                          <th className="px-3 py-2 font-semibold">Línea</th>
                          <th className="px-3 py-2 font-semibold">Ítem</th>
                          <th className="px-3 py-2 font-semibold">Descripción</th>
                          <th className="px-3 py-2 text-right font-semibold">Monto</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {selectedDocumento.detalle_items_xml.map((item, index) => (
                          <tr key={index}>
                            <td className="px-3 py-2 text-slate-700">
                              {String(item.numero_linea ?? index + 1)}
                            </td>
                            <td className="px-3 py-2 text-slate-700">
                              {String(item.nombre_item ?? '-')}
                            </td>
                            <td className="px-3 py-2 text-slate-700">
                              {String(item.descripcion_item ?? '-')}
                            </td>
                            <td className="px-3 py-2 text-right font-medium text-slate-900">
                              {formatCurrency(
                                typeof item.monto_item === 'number'
                                  ? item.monto_item
                                  : String(item.monto_item ?? 0)
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : null}
              </div>
            ) : null}

            {getAjusteSiiInfo(selectedDocumento) ? (
              <div
                className={`mt-6 rounded-2xl border p-4 text-sm ${
                  getAjusteSiiInfo(selectedDocumento)?.className
                }`}
              >
                <p className="font-semibold">
                  {getAjusteSiiInfo(selectedDocumento)?.title}
                </p>
                <p className="mt-1">
                  {getAjusteSiiInfo(selectedDocumento)?.message}
                </p>
              </div>
            ) : null}
            <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-5">
              <h4 className="text-base font-semibold text-slate-900">
                Datos para crear movimiento
              </h4>
              <p className="mt-1 text-sm text-slate-500">
                Completa o ajusta estos datos antes de crear el ingreso, egreso o ajuste.
              </p>

              <div className="mt-5">
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  Descripción para movimiento
                </label>
                <textarea
                  value={reviewForm.descripcion}
                  onChange={(event) =>
                    setReviewForm((prev) => ({
                      ...prev,
                      descripcion: event.target.value,
                    }))
                  }
                  rows={3}
                  className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
                />
              </div>

              <div className="mt-5 grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-700">
                    {selectedDocumento.tipo_registro === 'ventas' ? 'Cliente' : 'Proveedor'}
                  </label>
                  <select
                    value={reviewForm.tercero_id}
                    onChange={(event) => {
                      const terceroId = event.target.value
                      const terceros =
                        selectedDocumento.tipo_registro === 'ventas' ? clientes : proveedores
                      const terceroSeleccionado = terceros.find(
                        (tercero) => tercero.id === terceroId
                      )

                      setReviewForm((prev) => ({
                        ...prev,
                        tercero_id: terceroId,
                        fecha_vencimiento: terceroId
                          ? calcularFechaVencimientoSugerida(
                              selectedDocumento,
                              terceroSeleccionado
                            )
                          : prev.fecha_vencimiento,
                      }))
                    }}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
                  >
                    <option value="">
                      {selectedDocumento.tipo_registro === 'ventas'
                        ? 'Seleccionar cliente'
                        : 'Seleccionar proveedor'}
                    </option>
                    {(selectedDocumento.tipo_registro === 'ventas'
                      ? clientes
                      : proveedores
                    ).map((tercero) => (
                      <option key={tercero.id} value={tercero.id}>
                        {tercero.nombre}
                        {tercero.rut ? ` - ${tercero.rut}` : ''}
                        {getCondicionPagoLabel(tercero)
                          ? ` · ${getCondicionPagoLabel(tercero)}`
                          : ''}
                      </option>
                    ))}
                  </select>
                  {reviewForm.tercero_id ? (
                    <p className="mt-1 text-xs text-slate-500">
                      Vencimiento sugerido según condición del{' '}
                      {selectedDocumento.tipo_registro === 'ventas' ? 'cliente' : 'proveedor'}:{' '}
                      {getCondicionPagoLabel(
                        (selectedDocumento.tipo_registro === 'ventas'
                          ? clientes
                          : proveedores
                        ).find((tercero) => tercero.id === reviewForm.tercero_id)
                      )}
                    </p>
                  ) : null}
                  {!reviewForm.tercero_id ? (
                    <p className="mt-1 text-xs text-amber-600">
                      No se detectó automáticamente por RUT. Selecciona uno antes de crear el movimiento.
                    </p>
                  ) : null}
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-700">
                    Categoría
                  </label>
                  <select
                    value={reviewForm.categoria_id}
                    onChange={(event) =>
                      setReviewForm((prev) => ({
                        ...prev,
                        categoria_id: event.target.value,
                      }))
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
                  >
                    <option value="">Seleccionar categoría</option>
                    {categorias
                      .filter((categoria) => {
                        if (!categoria.tipo) return true
                        return selectedDocumento.tipo_registro === 'ventas'
                          ? categoria.tipo === 'ingreso'
                          : categoria.tipo === 'egreso'
                      })
                      .map((categoria) => (
                        <option key={categoria.id} value={categoria.id}>
                          {categoria.nombre}
                        </option>
                      ))}
                  </select>
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-700">
                    Centro de costo
                  </label>
                  <select
                    value={reviewForm.centro_costo_id}
                    onChange={(event) =>
                      setReviewForm((prev) => ({
                        ...prev,
                        centro_costo_id: event.target.value,
                      }))
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
                  >
                    <option value="">Sin centro de costo</option>
                    {centrosCosto.map((centro) => (
                      <option key={centro.id} value={centro.id}>
                        {centro.nombre}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-700">
                    Estado del movimiento
                  </label>
                  <select
                    value={reviewForm.estado_pago}
                    onChange={(event) =>
                      setReviewForm((prev) => ({
                        ...prev,
                        estado_pago: event.target.value as 'pendiente' | 'pagado',
                      }))
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
                  >
                    <option value="pendiente">Pendiente de pago</option>
                    <option value="pagado">Pagado</option>
                  </select>
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-700">
                    Fecha vencimiento
                  </label>
                  <input
                    type="date"
                    value={reviewForm.fecha_vencimiento}
                    onChange={(event) =>
                      setReviewForm((prev) => ({
                        ...prev,
                        fecha_vencimiento: event.target.value,
                      }))
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
                  />
                </div>

                {reviewForm.estado_pago === 'pagado' ? (
                  <div>
                    <label className="mb-2 block text-sm font-medium text-slate-700">
                      Cuenta bancaria
                    </label>
                    <select
                      value={reviewForm.cuenta_bancaria_id}
                      onChange={(event) =>
                        setReviewForm((prev) => ({
                          ...prev,
                          cuenta_bancaria_id: event.target.value,
                        }))
                      }
                      className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-[#163A5F]"
                    >
                      <option value="">Seleccionar cuenta bancaria</option>
                      {cuentasBancarias.map((cuenta) => (
                        <option key={cuenta.id} value={cuenta.id}>
                          {cuenta.banco} - {cuenta.nombre_cuenta}
                        </option>
                      ))}
                    </select>
                  </div>
                ) : null}
              </div>
            </div>
            <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
              Revisa cuidadosamente los datos antes de crear el movimiento. Al confirmar, el documento SII quedará asociado al ingreso, egreso o ajuste creado.
            </div>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={closeReviewModal}
                className="rounded-xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100"
              >
                Cancelar
              </button>

              <button
                type="button"
                onClick={() => void handleMarcarDocumental()}
                disabled={creatingMovimiento || selectedDocumento.estado === "convertido"}
                className="rounded-xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-60"
              >
                Marcar documental
              </button>

              <button
                type="button"
                onClick={() => void handleCrearMovimientoDesdeSii()}
                disabled={
                  creatingMovimiento ||
                  selectedDocumento.estado === "convertido" ||
                  Boolean(selectedDocumento.movimiento_id) ||
                  selectedDocumento.accion_sugerida === "solo_documental"
                }
                className="rounded-xl bg-[#163A5F] px-5 py-3 text-sm font-semibold text-white hover:bg-[#245C90] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {creatingMovimiento
                  ? "Creando..."
                  : getMovimientoLabelFromDoc(selectedDocumento)}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  )
}

export default function DocumentosSiiPage() {
  return (
    <ProtectedModuleRoute moduleKey="egresos">
      <DocumentosSiiPageContent />
    </ProtectedModuleRoute>
  )
}