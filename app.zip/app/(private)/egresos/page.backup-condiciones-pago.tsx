'use client'

import Link from 'next/link'
import {
  type ChangeEvent,
  type FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '../../../lib/supabase/client'
import StatusBadge from '../../../components/StatusBadge'
import EmpresaActivaBanner from '../../../components/EmpresaActivaBanner'
import ProtectedModuleRoute from '@/components/ProtectedModuleRoute'

type Proveedor = {
  id: string
  nombre: string
}

type CuentaBancaria = {
  id: string
  banco: string
  nombre_cuenta: string
}

type Categoria = {
  id: string
  empresa_id: string
  nombre: string
  tipo: 'ingreso' | 'egreso'
  clasificacion_financiera: string | null
  activa: boolean
}

type CentroCosto = {
  id: string
  empresa_id: string
  nombre: string
}

type TratamientoTributario = 'afecto_iva' | 'exento' | 'mixto' | 'combustible'

type Egreso = {
  id: string
  fecha: string
  tipo_documento: string | null
  numero_documento: string | null
  descripcion: string
  tratamiento_tributario: string | null
  monto_neto: number | null
  monto_exento: number | null
  monto_iva: number | null
  impuesto_especifico: number | null
  monto_total: number
  estado: string
  proveedor_id: string | null
  proveedor_nombre?: string | null
  categoria_id: string | null
  categoria_nombre?: string | null
  centro_costo_id: string | null
  centro_costo_nombre?: string | null
  cuenta_bancaria_id: string | null
  cuenta_bancaria_nombre?: string | null
  empresa_id: string
}

type FormData = {
  fecha: string
  tipo_documento: string
  numero_documento: string
  descripcion: string
  tratamiento_tributario: TratamientoTributario
  monto_neto: string
  monto_exento: string
  monto_iva: string
  impuesto_especifico: string
  monto_total: string
  estado: string
  proveedor_id: string
  categoria_id: string
  centro_costo_id: string
  cuenta_bancaria_id: string
}

type FiltroEstado = 'todos' | 'pendiente' | 'pagado' | 'anulado'

type Filters = {
  estado: FiltroEstado
  fechaDesde: string
  fechaHasta: string
  numeroDocumento: string
  proveedorId: string
  texto: string
}

const STORAGE_KEY = 'empresa_activa_id'
const IVA_RATE = 0.19

const buildInitialForm = (): FormData => ({
  fecha: new Date().toISOString().slice(0, 10),
  tipo_documento: 'factura',
  numero_documento: '',
  descripcion: '',
  tratamiento_tributario: 'afecto_iva',
  monto_neto: '',
  monto_exento: '',
  monto_iva: '',
  impuesto_especifico: '0',
  monto_total: '',
  estado: 'pendiente',
  proveedor_id: '',
  categoria_id: '',
  centro_costo_id: '',
  cuenta_bancaria_id: '',
})

const buildInitialFilters = (): Filters => ({
  estado: 'todos',
  fechaDesde: '',
  fechaHasta: '',
  numeroDocumento: '',
  proveedorId: '',
  texto: '',
})

const formatCLP = (value: number) => `$${Number(value || 0).toLocaleString('es-CL')}`

const normalizarTextoBusqueda = (value: string | number | null | undefined) =>
  String(value ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()

const normalizarMontoBusqueda = (value: string | number | null | undefined) =>
  String(value ?? '').replace(/[^\d-]/g, '')

const coincideMontoBusqueda = (
  busqueda: string,
  montos: Array<number | string | null | undefined>
) => {
  const montoBuscado = normalizarMontoBusqueda(busqueda)

  if (!montoBuscado) return false

  return montos.some((monto) => {
    const montoNormalizado = normalizarMontoBusqueda(
      Math.round(Number(monto ?? 0))
    )

    return montoNormalizado === montoBuscado || montoNormalizado.includes(montoBuscado)
  })
}


const formatDate = (value: string | null) => {
  if (!value) return '-'
  const date = new Date(`${value}T00:00:00`)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleDateString('es-CL')
}

const formatTratamientoTributario = (value: string | null | undefined) => {
  switch (value) {
    case 'afecto_iva':
      return 'Con IVA'
    case 'exento':
      return 'Exento de IVA'
    case 'mixto':
      return 'Con IVA + Exento IVA'
    case 'combustible':
      return 'IVA + Impuesto específico'
    default:
      return value || '-'
  }
}

const inferTratamientoTributario = (item: Egreso): TratamientoTributario => {
  if (item.tratamiento_tributario === 'afecto_iva') return 'afecto_iva'
  if (item.tratamiento_tributario === 'exento') return 'exento'
  if (item.tratamiento_tributario === 'mixto') return 'mixto'
  if (item.tratamiento_tributario === 'combustible') return 'combustible'

  const neto = Number(item.monto_neto || 0)
  const exento = Number(item.monto_exento || 0)
  const impuestoEspecifico = Number(item.impuesto_especifico || 0)

  if (impuestoEspecifico > 0) return 'combustible'
  if (neto > 0 && exento > 0) return 'mixto'
  if (exento > 0 && neto <= 0) return 'exento'
  return 'afecto_iva'
}

function FormModal({
  open,
  title,
  subtitle,
  onClose,
  children,
}: {
  open: boolean
  title: string
  subtitle: string
  onClose: () => void
  children: React.ReactNode
}) {
  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
      <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <h2 className="text-2xl font-semibold text-slate-900">{title}</h2>
            <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-slate-300 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            Cerrar
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

export default function EgresosPage() {
  const router = useRouter()

  const [empresaActivaId, setEmpresaActivaId] = useState('')
  const [proveedores, setProveedores] = useState<Proveedor[]>([])
  const [cuentas, setCuentas] = useState<CuentaBancaria[]>([])
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [centrosCosto, setCentrosCosto] = useState<CentroCosto[]>([])
  const [egresos, setEgresos] = useState<Egreso[]>([])

  const [formData, setFormData] = useState<FormData>(buildInitialForm())
  const [filters, setFilters] = useState<Filters>(buildInitialFilters())
  const [editingId, setEditingId] = useState<string | null>(null)
  const [usuarioRol, setUsuarioRol] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)
  const [showModal, setShowModal] = useState(false)

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  useEffect(() => {
    const syncEmpresaActiva = () => {
      const empresaId = window.localStorage.getItem(STORAGE_KEY) || ''
      setEmpresaActivaId(empresaId)
    }

    syncEmpresaActiva()
    window.addEventListener('empresa-activa-cambiada', syncEmpresaActiva)

    return () => {
      window.removeEventListener('empresa-activa-cambiada', syncEmpresaActiva)
    }
  }, [])

  const loadData = useCallback(async () => {
    if (!empresaActivaId) return

    try {
      setLoading(true)
      setError('')

      const { data: sessionData } = await supabase.auth.getSession()

      if (!sessionData.session) {
        router.push('/login')
        return
      }

      const accessToken = sessionData.session.access_token
      const userId = sessionData.session.user.id
      const apiKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
      const baseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''

      const headers = {
        apikey: apiKey,
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      }

      const [
        proveedoresResp,
        cuentasResp,
        categoriasResp,
        centrosResp,
        egresosResp,
        rolResp,
      ] = await Promise.all([
        fetch(
          `${baseUrl}/rest/v1/proveedores?select=id,nombre&empresa_id=eq.${empresaActivaId}&activo=eq.true&deleted_at=is.null&order=nombre.asc`,
          { headers }
        ),
        fetch(
          `${baseUrl}/rest/v1/cuentas_bancarias?select=id,banco,nombre_cuenta&empresa_id=eq.${empresaActivaId}&activa=eq.true&deleted_at=is.null&order=banco.asc`,
          { headers }
        ),
        fetch(
          `${baseUrl}/rest/v1/categorias?select=id,empresa_id,nombre,tipo,clasificacion_financiera,activa&empresa_id=eq.${empresaActivaId}&tipo=eq.egreso&activa=eq.true&deleted_at=is.null&order=nombre.asc`,
          { headers }
        ),
        fetch(
          `${baseUrl}/rest/v1/centros_costo?select=id,empresa_id,nombre&empresa_id=eq.${empresaActivaId}&activo=eq.true&deleted_at=is.null&order=nombre.asc`,
          { headers }
        ),
        fetch(
          `${baseUrl}/rest/v1/movimientos?select=id,fecha,tipo_documento,numero_documento,descripcion,tratamiento_tributario,monto_neto,monto_exento,monto_iva,impuesto_especifico,monto_total,estado,proveedor_id,categoria_id,centro_costo_id,cuenta_bancaria_id,empresa_id,activo,deleted_at&empresa_id=eq.${empresaActivaId}&tipo_movimiento=eq.egreso&activo=eq.true&deleted_at=is.null&order=fecha.desc`,
          { headers }
        ),
        fetch(
          `${baseUrl}/rest/v1/usuario_empresas?select=rol&usuario_id=eq.${userId}&empresa_id=eq.${empresaActivaId}&activo=eq.true`,
          { headers }
        ),
      ])

      const proveedoresJson = await proveedoresResp.json()
      const cuentasJson = await cuentasResp.json()
      const categoriasJson = await categoriasResp.json()
      const centrosJson = await centrosResp.json()
      const egresosJson = await egresosResp.json()
      const rolJson = await rolResp.json()

      if (!proveedoresResp.ok) {
        setError('No se pudieron cargar los proveedores.')
        return
      }
      if (!cuentasResp.ok) {
        setError('No se pudieron cargar las cuentas bancarias.')
        return
      }
      if (!categoriasResp.ok) {
        setError('No se pudieron cargar las categorías.')
        return
      }
      if (!centrosResp.ok) {
        setError('No se pudieron cargar los centros de costo.')
        return
      }
      if (!egresosResp.ok) {
        setError('No se pudieron cargar los egresos.')
        return
      }
      if (!rolResp.ok) {
        setError('No se pudo cargar el rol del usuario.')
        return
      }

      const proveedoresData = (proveedoresJson ?? []) as Proveedor[]
      const cuentasData = (cuentasJson ?? []) as CuentaBancaria[]
      const categoriasData = (categoriasJson ?? []) as Categoria[]
      const centrosData = (centrosJson ?? []) as CentroCosto[]
      const egresosBase = (egresosJson ?? []) as Egreso[]

      const rol =
        Array.isArray(rolJson) && rolJson.length > 0 ? rolJson[0].rol || '' : ''

      setUsuarioRol(rol)
      setIsAdmin(rol === 'admin')

      const proveedoresMap = new Map(proveedoresData.map((item) => [item.id, item.nombre]))
      const cuentasMap = new Map(
        cuentasData.map((item) => [item.id, `${item.banco} · ${item.nombre_cuenta}`])
      )
      const categoriasMap = new Map(categoriasData.map((item) => [item.id, item.nombre]))
      const centrosMap = new Map(centrosData.map((item) => [item.id, item.nombre]))

      const egresosEnriquecidos = egresosBase.map((item) => ({
        ...item,
        proveedor_nombre: item.proveedor_id ? proveedoresMap.get(item.proveedor_id) || '-' : '-',
        categoria_nombre: item.categoria_id ? categoriasMap.get(item.categoria_id) || '-' : '-',
        centro_costo_nombre: item.centro_costo_id ? centrosMap.get(item.centro_costo_id) || '-' : '-',
        cuenta_bancaria_nombre: item.cuenta_bancaria_id ? cuentasMap.get(item.cuenta_bancaria_id) || '-' : '-',
      }))

      setProveedores(proveedoresData)
      setCuentas(cuentasData)
      setCategorias(categoriasData)
      setCentrosCosto(centrosData)
      setEgresos(egresosEnriquecidos)
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message)
      } else {
        setError('Error desconocido al cargar egresos.')
      }
    } finally {
      setLoading(false)
    }
  }, [empresaActivaId, router])

  useEffect(() => {
    void loadData()
  }, [loadData])

  useEffect(() => {
    const neto = Number(formData.monto_neto || 0)
    const exento = Number(formData.monto_exento || 0)
    const impuestoEspecifico = Number(formData.impuesto_especifico || 0)

    let iva = 0
    let total = 0

    if (formData.tratamiento_tributario === 'afecto_iva') {
      iva = Math.round(neto * IVA_RATE)
      total = neto + iva
    } else if (formData.tratamiento_tributario === 'exento') {
      iva = 0
      total = exento
    } else if (formData.tratamiento_tributario === 'mixto') {
      iva = Math.round(neto * IVA_RATE)
      total = neto + iva + exento
    } else if (formData.tratamiento_tributario === 'combustible') {
      iva = Math.round(neto * IVA_RATE)
      total = neto + iva + impuestoEspecifico
    }

    const nextIva = iva ? String(iva) : ''
    const nextTotal = total ? String(total) : ''

    setFormData((prev) => {
      if (prev.monto_iva === nextIva && prev.monto_total === nextTotal) {
        return prev
      }
      return {
        ...prev,
        monto_iva: nextIva,
        monto_total: nextTotal,
      }
    })
  }, [formData.tratamiento_tributario, formData.monto_neto, formData.monto_exento, formData.impuesto_especifico])

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const resetForm = () => {
    setFormData(buildInitialForm())
    setEditingId(null)
  }

  const openNewModal = () => {
    if (!isAdmin) return
    resetForm()
    setError('')
    setSuccess('')
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    resetForm()
  }

  const handleEdit = (item: Egreso) => {
    if (!isAdmin) return

    const tratamiento = inferTratamientoTributario(item)

    setError('')
    setSuccess('')
    setEditingId(item.id)
    setFormData({
      fecha: item.fecha || new Date().toISOString().slice(0, 10),
      tipo_documento: item.tipo_documento || 'factura',
      numero_documento: item.numero_documento || '',
      descripcion: item.descripcion || '',
      tratamiento_tributario: tratamiento,
      monto_neto: String(Number(item.monto_neto || 0) || ''),
      monto_exento: String(Number(item.monto_exento || 0) || ''),
      monto_iva: String(Number(item.monto_iva || 0) || ''),
      impuesto_especifico: String(Number(item.impuesto_especifico || 0) || '0'),
      monto_total: String(item.monto_total || ''),
      estado: item.estado || 'pendiente',
      proveedor_id: item.proveedor_id || '',
      categoria_id: item.categoria_id || '',
      centro_costo_id: item.centro_costo_id || '',
      cuenta_bancaria_id: item.cuenta_bancaria_id || '',
    })
    setShowModal(true)
  }

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!isAdmin) {
      setError('Solo el administrador puede registrar o modificar egresos.')
      return
    }
    if (!empresaActivaId) {
      setError('No hay empresa activa seleccionada.')
      return
    }
    if (!formData.fecha || !formData.descripcion) {
      setError('Complete los campos obligatorios del egreso.')
      return
    }

    const neto = Number(formData.monto_neto || 0)
    const exento = Number(formData.monto_exento || 0)
    const iva = Number(formData.monto_iva || 0)
    const impuestoEspecifico = Number(formData.impuesto_especifico || 0)
    const total = Number(formData.monto_total || 0)

    if (formData.tratamiento_tributario === 'afecto_iva' && neto <= 0) {
      setError('Debes ingresar un monto neto afecto mayor a 0.')
      return
    }
    if (formData.tratamiento_tributario === 'exento' && exento <= 0) {
      setError('Debes ingresar un monto exento mayor a 0.')
      return
    }
    if (formData.tratamiento_tributario === 'mixto') {
      if (neto <= 0) {
        setError('Debes ingresar un monto neto afecto mayor a 0 para un documento mixto.')
        return
      }
      if (exento <= 0) {
        setError('Debes ingresar un monto exento mayor a 0 para un documento mixto.')
        return
      }
    }
    if (formData.tratamiento_tributario === 'combustible') {
      if (neto <= 0) {
        setError('Debes ingresar un monto neto afecto mayor a 0 para combustible.')
        return
      }
    }
    if (total <= 0) {
      setError('El monto total debe ser mayor a 0.')
      return
    }

    try {
      setSaving(true)
      setError('')
      setSuccess('')

      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData.session) {
        router.push('/login')
        return
      }

      const accessToken = sessionData.session.access_token
      const userId = sessionData.session.user.id
      const apiKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
      const baseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''

      const updatedAt = new Date().toISOString()

      const basePayload = {
        empresa_id: empresaActivaId,
        tipo_movimiento: 'egreso',
        fecha: formData.fecha,
        tipo_documento: formData.tipo_documento || null,
        numero_documento: formData.numero_documento || null,
        descripcion: formData.descripcion,
        tratamiento_tributario: formData.tratamiento_tributario,
        monto_neto: formData.tratamiento_tributario === 'exento' ? 0 : neto,
        monto_exento:
          formData.tratamiento_tributario === 'afecto_iva' ||
          formData.tratamiento_tributario === 'combustible'
            ? 0
            : exento,
        monto_iva: iva,
        impuesto_especifico:
          formData.tratamiento_tributario === 'combustible' ? impuestoEspecifico : 0,
        monto_total: total,
        estado: formData.estado,
        proveedor_id: formData.proveedor_id || null,
        categoria_id: formData.categoria_id || null,
        centro_costo_id: formData.centro_costo_id || null,
        cuenta_bancaria_id: formData.cuenta_bancaria_id || null,
        updated_by: userId,
        updated_at: updatedAt,
      }

      const isEditing = Boolean(editingId)
      const payload = isEditing
        ? basePayload
        : {
            ...basePayload,
            created_by: userId,
            activo: true,
            deleted_at: null,
            deleted_by: null,
          }

      const url = isEditing
        ? `${baseUrl}/rest/v1/movimientos?id=eq.${editingId}&empresa_id=eq.${empresaActivaId}&tipo_movimiento=eq.egreso&activo=eq.true&deleted_at=is.null`
        : `${baseUrl}/rest/v1/movimientos`
      const method = isEditing ? 'PATCH' : 'POST'

      const resp = await fetch(url, {
        method,
        headers: {
          apikey: apiKey,
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          Prefer: 'return=representation',
        },
        body: JSON.stringify(payload),
      })

      const json = await resp.json()

      if (!resp.ok) {
        console.error(json)
        setError(isEditing ? 'No se pudo actualizar el egreso.' : 'No se pudo registrar el egreso.')
        return
      }

      setSuccess(isEditing ? 'Egreso actualizado correctamente.' : 'Egreso registrado correctamente.')
      closeModal()
      await loadData()
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message)
      } else {
        setError('Error desconocido al guardar el egreso.')
      }
    } finally {
      setSaving(false)
    }
  }

  const handleArchivar = async (item: Egreso) => {
    if (!isAdmin) {
      setError('Solo el administrador puede archivar egresos.')
      return
    }

    const confirmacion = window.confirm(
      `¿Desea archivar el egreso "${item.descripcion}"? No se borrará de la base de datos.`
    )
    if (!confirmacion) return

    try {
      setError('')
      setSuccess('')

      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData.session) {
        router.push('/login')
        return
      }

      const accessToken = sessionData.session.access_token
      const userId = sessionData.session.user.id
      const apiKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
      const baseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
      const deletedAt = new Date().toISOString()

      const resp = await fetch(
        `${baseUrl}/rest/v1/movimientos?id=eq.${item.id}&empresa_id=eq.${empresaActivaId}&tipo_movimiento=eq.egreso&activo=eq.true&deleted_at=is.null`,
        {
          method: 'PATCH',
          headers: {
            apikey: apiKey,
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
            Prefer: 'return=representation',
          },
          body: JSON.stringify({
            estado: 'anulado',
            activo: false,
            deleted_at: deletedAt,
            deleted_by: userId,
            updated_by: userId,
            updated_at: deletedAt,
          }),
        }
      )

      const json = await resp.json()
      if (!resp.ok) {
        console.error(json)
        setError('No se pudo archivar el egreso.')
        return
      }

      if (editingId === item.id) closeModal()

      setSuccess('Egreso archivado correctamente.')
      await loadData()
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message)
      } else {
        setError('Error desconocido al archivar el egreso.')
      }
    }
  }

  const egresosFiltrados = useMemo(() => {
    return egresos.filter((item) => {
      const estado = normalizarTextoBusqueda(item.estado)
      const numeroDocumento = normalizarTextoBusqueda(item.numero_documento)
      const descripcion = normalizarTextoBusqueda(item.descripcion)
      const proveedorId = item.proveedor_id || ''
      const fecha = item.fecha || ''
      const search = normalizarTextoBusqueda(filters.texto)
      const numeroDocumentoFiltro = normalizarTextoBusqueda(filters.numeroDocumento)

      const camposBusqueda = [
        item.tipo_documento,
        item.numero_documento,
        item.descripcion,
        item.proveedor_nombre,
        item.categoria_nombre,
        item.centro_costo_nombre,
        item.cuenta_bancaria_nombre,
        item.estado,
        item.tratamiento_tributario,
        formatCLP(Number(item.monto_total || 0)),
        formatCLP(Number(item.monto_neto || 0)),
        formatCLP(Number(item.monto_iva || 0)),
        formatCLP(Number(item.monto_exento || 0)),
        formatCLP(Number(item.impuesto_especifico || 0)),
      ]
        .map(normalizarTextoBusqueda)
        .join(' ')

      const matchesEstado = filters.estado === 'todos' || estado === filters.estado
      const matchesDesde = !filters.fechaDesde || fecha >= filters.fechaDesde
      const matchesHasta = !filters.fechaHasta || fecha <= filters.fechaHasta
      const matchesNumero = !numeroDocumentoFiltro || numeroDocumento.includes(numeroDocumentoFiltro)
      const matchesProveedor = !filters.proveedorId || proveedorId === filters.proveedorId
      const matchesTexto =
        !search ||
        camposBusqueda.includes(search) ||
        coincideMontoBusqueda(filters.texto, [
          item.monto_total,
          item.monto_neto,
          item.monto_iva,
          item.monto_exento,
          item.impuesto_especifico,
        ])

      return matchesEstado && matchesDesde && matchesHasta && matchesNumero && matchesProveedor && matchesTexto
    })
  }, [egresos, filters])

  const totalEgresos = useMemo(
    () => egresosFiltrados.reduce((acc, item) => acc + Number(item.monto_total || 0), 0),
    [egresosFiltrados]
  )

  const egresosPendientes = useMemo(
    () => egresosFiltrados.filter((item) => (item.estado || '').toLowerCase() === 'pendiente').length,
    [egresosFiltrados]
  )

  const egresosPagados = useMemo(
    () => egresosFiltrados.filter((item) => (item.estado || '').toLowerCase() === 'pagado').length,
    [egresosFiltrados]
  )

  const egresosAnulados = useMemo(
    () => egresosFiltrados.filter((item) => (item.estado || '').toLowerCase() === 'anulado').length,
    [egresosFiltrados]
  )

  return (
    <ProtectedModuleRoute moduleKey="egresos">
      <main className="space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-4xl font-semibold text-slate-900">Egresos</h1>
            <p className="mt-2 text-slate-600">
              Registro, control y seguimiento de egresos de la empresa activa.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            {isAdmin ? (
              <button
                type="button"
                onClick={openNewModal}
                className="rounded-xl bg-[#163A5F] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#245C90]"
              >
                Nuevo egreso
              </button>
            ) : null}

            <Link
              href="/reportes"
              className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
            >
              Ver reporte de egresos
            </Link>
          </div>
        </div>

        <EmpresaActivaBanner
          modulo="Egresos"
          descripcion="Todos los registros visibles corresponden únicamente a la empresa activa seleccionada."
        />

        {!isAdmin && !loading ? (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            El usuario actual tiene rol{' '}
            <span className="font-semibold">{usuarioRol || 'sin rol asignado'}</span>.
            Solo el administrador puede registrar, editar o archivar egresos.
          </div>
        ) : null}

        <section className="rounded-2xl border-2 border-[#163A5F] bg-white p-4 shadow-sm">
          <div className="mb-4 flex flex-col gap-1">
            <h2 className="text-lg font-semibold text-slate-900">Filtros de egresos</h2>
            <p className="text-sm text-slate-500">
              Busca por fecha, documento, proveedor, descripción o monto total/neto.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-6">
            <div className="xl:col-span-1">
              <label className="mb-1 block text-sm font-medium text-slate-700">Estado</label>
              <select
                value={filters.estado}
                onChange={(e) => setFilters((prev) => ({ ...prev, estado: e.target.value as FiltroEstado }))}
                className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
              >
                <option value="todos">Todos</option>
                <option value="pendiente">Pendiente</option>
                <option value="pagado">Pagado</option>
                <option value="anulado">Anulado</option>
              </select>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Desde</label>
              <input
                type="date"
                value={filters.fechaDesde}
                onChange={(e) => setFilters((prev) => ({ ...prev, fechaDesde: e.target.value }))}
                className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Hasta</label>
              <input
                type="date"
                value={filters.fechaHasta}
                onChange={(e) => setFilters((prev) => ({ ...prev, fechaHasta: e.target.value }))}
                className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">N° documento</label>
              <input
                type="text"
                value={filters.numeroDocumento}
                onChange={(e) => setFilters((prev) => ({ ...prev, numeroDocumento: e.target.value }))}
                placeholder="Ej: 12345"
                className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Proveedor</label>
              <select
                value={filters.proveedorId}
                onChange={(e) => setFilters((prev) => ({ ...prev, proveedorId: e.target.value }))}
                className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
              >
                <option value="">Todos</option>
                {proveedores.map((item) => (
                  <option key={item.id} value={item.id}>{item.nombre}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Buscar</label>
              <input
                type="text"
                value={filters.texto}
                onChange={(e) => setFilters((prev) => ({ ...prev, texto: e.target.value }))}
                placeholder="Descripción, proveedor, categoría o monto"
                className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
              />
            </div>
          </div>
        </section>

        {!loading && !error ? (
          <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <p className="text-sm text-slate-500">Total egresos filtrados</p>
              <h2 className="mt-2 text-3xl font-semibold text-slate-900">{formatCLP(totalEgresos)}</h2>
            </article>
            <article className="rounded-2xl border border-amber-200 bg-amber-50 p-5 shadow-sm">
              <p className="text-sm text-amber-700">Pendientes</p>
              <h2 className="mt-2 text-3xl font-semibold text-amber-900">{egresosPendientes}</h2>
            </article>
            <article className="rounded-2xl border border-emerald-200 bg-emerald-50 p-5 shadow-sm">
              <p className="text-sm text-emerald-700">Pagados</p>
              <h2 className="mt-2 text-3xl font-semibold text-emerald-900">{egresosPagados}</h2>
            </article>
            <article className="rounded-2xl border border-slate-300 bg-slate-50 p-5 shadow-sm">
              <p className="text-sm text-slate-600">Anulados</p>
              <h2 className="mt-2 text-3xl font-semibold text-slate-900">{egresosAnulados}</h2>
            </article>
          </section>
        ) : null}

        {error ? (
          <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        ) : null}

        {success ? (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            {success}
          </div>
        ) : null}

        <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="text-2xl font-semibold text-slate-900">Listado de egresos</h2>
              <p className="mt-1 text-sm text-slate-500">
                Historial filtrado de egresos registrados para la empresa activa.
              </p>
            </div>
            <div className="text-sm text-slate-500">{egresosFiltrados.length} registro(s)</div>
          </div>

          {loading ? (
            <p className="text-sm text-slate-500">Cargando egresos...</p>
          ) : egresosFiltrados.length === 0 ? (
            <p className="text-sm text-slate-500">No hay egresos para los filtros seleccionados.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-[1320px] w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-slate-500">
                    <th className="py-3 pr-4">Fecha</th>
                    <th className="py-3 pr-4">Documento</th>
                    <th className="py-3 pr-4">Descripción</th>
                    <th className="py-3 pr-4">Proveedor</th>
                    <th className="py-3 pr-4">Categoría</th>
                    <th className="py-3 pr-4">Centro costo</th>
                    <th className="py-3 pr-4">Cuenta bancaria</th>
                    <th className="py-3 pr-4">Tratamiento</th>
                    <th className="py-3 pr-4 text-right">Monto</th>
                    <th className="py-3 pr-4">Estado</th>
                    {isAdmin ? <th className="py-3 pr-4 text-right">Acciones</th> : null}
                  </tr>
                </thead>
                <tbody>
                  {egresosFiltrados.map((item) => (
                    <tr key={item.id} className="border-b border-slate-100 align-top">
                      <td className="py-3 pr-4 whitespace-nowrap">{formatDate(item.fecha)}</td>
                      <td className="py-3 pr-4 whitespace-nowrap">
                        <div className="font-medium text-slate-800">{item.tipo_documento || '-'}</div>
                        <div className="text-slate-500">{item.numero_documento || '-'}</div>
                      </td>
                      <td className="py-3 pr-4 min-w-[260px]">{item.descripcion}</td>
                      <td className="py-3 pr-4 whitespace-nowrap">{item.proveedor_nombre || '-'}</td>
                      <td className="py-3 pr-4 whitespace-nowrap">{item.categoria_nombre || '-'}</td>
                      <td className="py-3 pr-4 whitespace-nowrap">{item.centro_costo_nombre || '-'}</td>
                      <td className="py-3 pr-4 whitespace-nowrap">{item.cuenta_bancaria_nombre || '-'}</td>
                      <td className="py-3 pr-4 whitespace-nowrap">{formatTratamientoTributario(item.tratamiento_tributario)}</td>
                      <td className="py-3 pr-4 text-right font-medium">{formatCLP(item.monto_total)}</td>
                      <td className="py-3 pr-4"><StatusBadge status={item.estado} /></td>
                      {isAdmin ? (
                        <td className="py-3 pr-4 text-right">
                          <div className="flex justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => handleEdit(item)}
                              className="rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                            >
                              Editar
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleArchivar(item)}
                              className="rounded-xl border border-red-300 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50"
                            >
                              Archivar
                            </button>
                          </div>
                        </td>
                      ) : null}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <FormModal
          open={showModal}
          onClose={closeModal}
          title={editingId ? 'Editar egreso' : 'Nuevo egreso'}
          subtitle={editingId ? 'Modifique los datos del egreso seleccionado.' : 'Registre un nuevo movimiento de egreso para la empresa activa.'}
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Fecha</label>
                <input
                  type="date"
                  name="fecha"
                  value={formData.fecha}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                  required
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Tipo documento</label>
                <select
                  name="tipo_documento"
                  value={formData.tipo_documento}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                >
                  <option value="factura">Factura</option>
                  <option value="boleta">Boleta</option>
                  <option value="recibo">Recibo</option>
                  <option value="otro">Otro</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Número documento</label>
                <input
                  type="text"
                  name="numero_documento"
                  value={formData.numero_documento}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                  placeholder="Ej: 12345"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Estado</label>
                <select
                  name="estado"
                  value={formData.estado}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                >
                  <option value="pendiente">Pendiente</option>
                  <option value="pagado">Pagado</option>
                  <option value="anulado">Anulado</option>
                </select>
              </div>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Descripción</label>
              <textarea
                name="descripcion"
                value={formData.descripcion}
                onChange={handleChange}
                className="min-h-[100px] w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                placeholder="Detalle del egreso"
                required
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Tratamiento tributario</label>
              <select
                name="tratamiento_tributario"
                value={formData.tratamiento_tributario}
                onChange={handleChange}
                className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
              >
                <option value="afecto_iva">Con IVA</option>
                <option value="exento">Exento de IVA</option>
                <option value="mixto">Con IVA + Exento IVA</option>
                <option value="combustible">IVA + Impuesto específico</option>
              </select>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Neto afecto</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  name="monto_neto"
                  value={formData.monto_neto}
                  onChange={handleChange}
                  disabled={formData.tratamiento_tributario === 'exento'}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm disabled:bg-slate-50 disabled:text-slate-400"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Monto exento</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  name="monto_exento"
                  value={formData.monto_exento}
                  onChange={handleChange}
                  disabled={formData.tratamiento_tributario === 'afecto_iva' || formData.tratamiento_tributario === 'combustible'}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm disabled:bg-slate-50 disabled:text-slate-400"
                  placeholder="0"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">IVA</label>
                <input
                  type="number"
                  name="monto_iva"
                  value={formData.monto_iva}
                  readOnly
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-4 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Impuesto específico</label>
                <input
                  type="number"
                  step="1"
                  name="impuesto_especifico"
                  value={formData.impuesto_especifico}
                  onChange={handleChange}
                  disabled={formData.tratamiento_tributario !== 'combustible'}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm disabled:bg-slate-50 disabled:text-slate-400"
                  placeholder="0"
                />
              </div>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Total</label>
              <input
                type="number"
                name="monto_total"
                value={formData.monto_total}
                readOnly
                className="w-full rounded-xl border border-slate-300 bg-slate-50 px-4 py-2.5 text-sm font-medium"
              />
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Proveedor</label>
                <select
                  name="proveedor_id"
                  value={formData.proveedor_id}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                >
                  <option value="">Seleccionar proveedor</option>
                  {proveedores.map((item) => (
                    <option key={item.id} value={item.id}>{item.nombre}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Categoría</label>
                <select
                  name="categoria_id"
                  value={formData.categoria_id}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                >
                  <option value="">Seleccionar categoría</option>
                  {categorias.map((item) => (
                    <option key={item.id} value={item.id}>{item.nombre}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Centro de costo</label>
                <select
                  name="centro_costo_id"
                  value={formData.centro_costo_id}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                >
                  <option value="">Seleccionar centro de costo</option>
                  {centrosCosto.map((item) => (
                    <option key={item.id} value={item.id}>{item.nombre}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">Cuenta bancaria</label>
                <select
                  name="cuenta_bancaria_id"
                  value={formData.cuenta_bancaria_id}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm"
                >
                  <option value="">Seleccionar cuenta</option>
                  {cuentas.map((item) => (
                    <option key={item.id} value={item.id}>{item.banco} · {item.nombre_cuenta}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex flex-col gap-3 pt-2 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={closeModal}
                className="rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={saving}
                className="rounded-xl bg-[#163A5F] px-4 py-2.5 text-sm font-medium text-white transition hover:bg-[#245C90] disabled:opacity-70"
              >
                {saving ? (editingId ? 'Actualizando...' : 'Guardando...') : editingId ? 'Actualizar egreso' : 'Registrar egreso'}
              </button>
            </div>
          </form>
        </FormModal>
      </main>
    </ProtectedModuleRoute>
  )
}
