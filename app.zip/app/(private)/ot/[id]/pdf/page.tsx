'use client'

import Link from 'next/link'
import { useParams } from 'next/navigation'
import { useEffect, useMemo, useRef, useState } from 'react'
import ProtectedModuleRoute from '../../../../../components/ProtectedModuleRoute'
import { supabase } from '../../../../../lib/supabase/client'

function sanitizeFileNamePart(value: string) {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9\s._-]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80)
}

function buildOtPdfFileName(params: {
  folio?: string | null
  cliente?: string | null
  otId: string
}) {
  const folio = sanitizeFileNamePart(params.folio || '') || `OT-${params.otId.slice(0, 8)}`
  const cliente = sanitizeFileNamePart(params.cliente || '')

  return cliente ? `${folio} - ${cliente}.pdf` : `${folio}.pdf`
}

function OTPdfRealPageContent() {
  const params = useParams()

  const otId = useMemo(() => {
    const raw = params?.id
    if (typeof raw === 'string') return raw
    if (Array.isArray(raw)) return raw[0] ?? ''
    return ''
  }, [params])

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [blobUrl, setBlobUrl] = useState('')
  const [fileName, setFileName] = useState('ot.pdf')
  const [isIOS, setIsIOS] = useState(false)

  const blobUrlRef = useRef('')

  useEffect(() => {
    const isiPadOrIOS =
      /iPad|iPhone|iPod/.test(window.navigator.userAgent) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)

    setIsIOS(isiPadOrIOS)
  }, [])

  useEffect(() => {
    let active = true

    const loadPdf = async () => {
      try {
        setLoading(true)
        setError('')

        if (!otId) {
          throw new Error('No se recibió el identificador de la OT.')
        }

        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession()

        if (sessionError) {
          throw new Error(`No se pudo validar la sesión: ${sessionError.message}`)
        }

        if (!session?.access_token) {
          throw new Error('No hay sesión activa para generar el PDF.')
        }

        let nextFileName = `ot-${otId}.pdf`

        const { data: otFileData } = await supabase
          .from('ot_vw_resumen')
          .select('folio, cliente_nombre')
          .eq('id', otId)
          .maybeSingle()

        if (otFileData) {
          nextFileName = buildOtPdfFileName({
            folio: (otFileData as { folio?: string | null }).folio,
            cliente: (otFileData as { cliente_nombre?: string | null }).cliente_nombre,
            otId,
          })
        }

        const response = await fetch(`/api/ot-pdf/${otId}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        })

        if (!response.ok) {
          const text = await response.text()
          throw new Error(text || 'No se pudo generar el PDF real.')
        }

        const blob = await response.blob()

        if (!active) return

        if (blobUrlRef.current) {
          URL.revokeObjectURL(blobUrlRef.current)
        }

        const nextBlobUrl = URL.createObjectURL(blob)
        blobUrlRef.current = nextBlobUrl
        setBlobUrl(nextBlobUrl)
        setFileName(nextFileName)
      } catch (err) {
        if (!active) return
        setError(err instanceof Error ? err.message : 'No se pudo generar el PDF real.')
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    void loadPdf()

    return () => {
      active = false
    }
  }, [otId])

  useEffect(() => {
    return () => {
      if (blobUrlRef.current) {
        URL.revokeObjectURL(blobUrlRef.current)
      }
    }
  }, [])

  const handleOpenPdf = () => {
    if (!blobUrl) return
    window.location.href = blobUrl
  }

  const handleSharePdf = async () => {
    try {
      if (!blobUrl) return

      const response = await fetch(blobUrl)
      const blob = await response.blob()
      const file = new File([blob], fileName, { type: 'application/pdf' })

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: fileName,
          files: [file],
        })
        return
      }

      window.location.href = blobUrl
    } catch (_error) {
      window.location.href = blobUrl
    }
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-6xl rounded-2xl border border-slate-200 bg-white p-8">
        Generando PDF real...
      </div>
    )
  }

  if (error) {
    return (
      <div className="mx-auto max-w-6xl space-y-4">
        <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-sm text-red-700">
          {error}
        </div>

        <Link
          href={`/ot/${otId}`}
          className="inline-flex items-center justify-center rounded-xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100"
        >
          Volver a la OT
        </Link>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">
              PDF real OT
            </h1>
            <p className="mt-2 text-sm text-slate-500">
              Este PDF ya viene generado por el servidor.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            {blobUrl ? (
              <>
                <button
                  type="button"
                  onClick={handleOpenPdf}
                  className="inline-flex items-center justify-center rounded-xl bg-[#163A5F] px-5 py-3 text-sm font-semibold text-white hover:bg-[#245C90]"
                >
                  Abrir PDF real
                </button>

                {isIOS ? (
                  <button
                    type="button"
                    onClick={handleSharePdf}
                    className="inline-flex items-center justify-center rounded-xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100"
                  >
                    Compartir PDF
                  </button>
                ) : (
                  <a
                    href={blobUrl}
                    download={fileName}
                    className="inline-flex items-center justify-center rounded-xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100"
                  >
                    Descargar PDF
                  </a>
                )}
              </>
            ) : null}

            <Link
              href={`/ot/${otId}`}
              className="inline-flex items-center justify-center rounded-xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100"
            >
              Volver a la OT
            </Link>
          </div>
        </div>
      </div>

      {blobUrl ? (
        isIOS ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <p className="text-sm text-slate-600">
              El PDF fue generado correctamente. En iPad conviene abrirlo o
              compartirlo con los botones superiores.
            </p>
          </div>
        ) : (
          <div className="rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
            <iframe
              title="PDF real OT"
              src={blobUrl}
              className="h-[85vh] w-full rounded-xl border border-slate-200"
            />
          </div>
        )
      ) : null}
    </div>
  )
}

export default function OTPdfRealPage() {
  return (
    <ProtectedModuleRoute moduleKey="ot">
      <OTPdfRealPageContent />
    </ProtectedModuleRoute>
  )
}